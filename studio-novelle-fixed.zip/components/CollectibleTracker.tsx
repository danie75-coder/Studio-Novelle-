"use client";

import { useState } from "react";
import { useCollectibles } from "@/lib/useCollectibles";

export default function CollectibleTracker() {
  const { count, total, allFound, hydrated } = useCollectibles();
  const [open, setOpen] = useState(false);

  // Nothing to show until at least one mark has been found — an
  // empty "0/7" badge sitting on every page would just spoil the
  // idea that there's something to look for.
  if (!hydrated || count === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-40">
      {open && (
        <div className="mb-3 w-64 bg-charcoal text-ivory p-5 rounded-sm shadow-lg">
          {allFound ? (
            <>
              <span className="font-mono text-[10px] uppercase tracking-wider text-gold block mb-2">
                All Found
              </span>
              <p className="font-display text-sm leading-relaxed mb-3">
                You found every mark on the site. Email{" "}
                <span className="text-gold">hello@studionovelle.com</span>{" "}
                and mention &ldquo;the seal&rdquo; for something off-menu.
              </p>
            </>
          ) : (
            <>
              <span className="font-mono text-[10px] uppercase tracking-wider text-gold block mb-2">
                Marks Found
              </span>
              <p className="text-sm text-ivory/70 leading-relaxed">
                {count} of {total} — the rest are scattered around, not
                announced.
              </p>
            </>
          )}
        </div>
      )}
      <button
        onClick={() => setOpen((o) => !o)}
        className="font-mono text-[10px] uppercase tracking-wider bg-charcoal text-ivory px-4 py-2.5 rounded-full opacity-70 hover:opacity-100 transition-opacity duration-300"
      >
        {allFound ? "✦" : `${count}/${total}`}
      </button>
    </div>
  );
}
