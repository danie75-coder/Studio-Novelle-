"use client";

import { useState } from "react";
import { useCollectibles } from "@/lib/useCollectibles";
import type { CollectibleId } from "@/lib/collectibles";

// A near-invisible dot placed somewhere unexpected on a page. Clicking
// it registers a find (persisted in localStorage) and shows a brief
// confirmation. Deliberately not styled to draw the eye — the whole
// point is that most visitors never notice it's there.
export default function HiddenMark({ id }: { id: CollectibleId }) {
  const { markFound, isFound, hydrated } = useCollectibles();
  const [justFound, setJustFound] = useState(false);

  function handleClick() {
    if (isFound(id)) return;
    markFound(id);
    setJustFound(true);
    setTimeout(() => setJustFound(false), 2200);
  }

  const already = hydrated && isFound(id);

  return (
    <span className="relative inline-block align-middle">
      <button
        type="button"
        onClick={handleClick}
        aria-label={already ? "Mark already found" : "?"}
        className={`inline-block w-[5px] h-[5px] rounded-full transition-all duration-500 cursor-default ${
          already ? "bg-gold opacity-40" : "bg-gold opacity-0 hover:opacity-60"
        }`}
        style={{ margin: "0 2px" }}
      />
      {justFound && (
        <span className="absolute left-1/2 -translate-x-1/2 -top-8 whitespace-nowrap font-mono text-[10px] uppercase tracking-wider text-gold bg-charcoal text-ivory px-3 py-1.5 rounded-sm pointer-events-none animate-[fadeIn_0.3s_ease]">
          Found ✦
        </span>
      )}
    </span>
  );
}
