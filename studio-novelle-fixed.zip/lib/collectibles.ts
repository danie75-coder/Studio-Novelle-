// The canonical set of hidden marks across the site. Adding a new
// hiding spot is just adding an id here and dropping <HiddenMark
// id="..."/> somewhere on the corresponding page — the tracker picks
// up the new total automatically.
export const COLLECTIBLE_IDS = [
  "home",
  "about",
  "hollow-moon",
  "veloura",
  "aurelia-hotels",
  "what-if",
  "materials",
] as const;

export type CollectibleId = (typeof COLLECTIBLE_IDS)[number];
