"use client";

import { useCallback, useEffect, useState } from "react";
import { COLLECTIBLE_IDS, type CollectibleId } from "./collectibles";

const STORAGE_KEY = "sn_collectibles";

function readStored(): Set<string> {
  if (typeof window === "undefined") return new Set();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return new Set(raw ? (JSON.parse(raw) as string[]) : []);
  } catch {
    return new Set();
  }
}

export function useCollectibles() {
  const [found, setFound] = useState<Set<string>>(new Set());
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setFound(readStored());
    setHydrated(true);
  }, []);

  const markFound = useCallback((id: CollectibleId) => {
    setFound((prev) => {
      if (prev.has(id)) return prev;
      const next = new Set(prev);
      next.add(id);
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify([...next]));
      return next;
    });
  }, []);

  const isFound = useCallback((id: CollectibleId) => found.has(id), [found]);

  return {
    found,
    markFound,
    isFound,
    hydrated,
    total: COLLECTIBLE_IDS.length,
    count: found.size,
    allFound: hydrated && found.size >= COLLECTIBLE_IDS.length,
  };
}
