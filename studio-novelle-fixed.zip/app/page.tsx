import Link from "next/link";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import Button from "@/components/Button";
import ProjectCard from "@/components/ProjectCard";
import HiddenMark from "@/components/HiddenMark";
import { projects } from "@/lib/projects";

export default function Home() {
  return (
    <>
      <Nav active="/" />

      <header className="max-w-[1180px] mx-auto px-8 pt-32 md:pt-36 pb-24">
        <Reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
            Studio Novelle — Creative Direction &amp; Brand Identity<HiddenMark id="home" />
          </span>
        </Reveal>
        <Reveal delay={0.1}>
          <h1 className="font-display font-light text-[52px] md:text-[96px] leading-[0.94] tracking-tight">
            Designed to
            <br />
            feel <em className="italic font-normal text-gold">expensive.</em>
          </h1>
        </Reveal>
        <Reveal delay={0.22}>
          <div className="flex justify-between items-end mt-14 gap-10 flex-wrap">
            <p className="max-w-[380px] text-stone text-base leading-relaxed">
              We help ambitious brands become unforgettable — through identity,
              creative direction, and the kind of detail that signals premium
              before a single word is read.
            </p>
            <div className="flex gap-4 flex-wrap">
              <Button href="/book" variant="primary">Book a Project</Button>
              <Button href="/work" variant="outline">View Selected Work</Button>
            </div>
          </div>
        </Reveal>
      </header>

      <Reveal>
        <section className="py-28 border-t border-b border-line bg-beige">
          <div className="max-w-[1180px] mx-auto px-8 grid md:grid-cols-[200px_1fr] gap-14">
            <span className="font-mono text-xs uppercase tracking-widest text-gold">
              Philosophy
            </span>
            <div>
              <h2 className="font-display text-[30px] md:text-[46px] leading-tight tracking-tight max-w-[680px]">
                <span className="block">We don&rsquo;t decorate brands.</span>
                <span className="block italic font-normal text-stone">
                  We build desire.
                </span>
              </h2>
              <Button href="/about" variant="ghost">Read the full manifesto →</Button>
            </div>
          </div>
        </section>
      </Reveal>

      <section className="max-w-[1180px] mx-auto px-8 py-28">
        <Reveal>
          <div className="flex justify-between items-end mb-14 gap-6 flex-wrap">
            <div>
              <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
                Selected Work
              </span>
              <h2 className="font-display text-[28px] md:text-[40px] tracking-tight">
                A growing archive of brand worlds
              </h2>
            </div>
            <Button href="/work" variant="ghost">View full archive →</Button>
          </div>
        </Reveal>
        <Reveal delay={0.1}>
          <div className="grid md:grid-cols-3 gap-px bg-line border border-line">
            {projects.map((p) => (
              <ProjectCard
                key={p.slug}
                href={`/work/${p.slug}`}
                fileNo={`File ${p.fileNo}`}
                name={p.name}
                industry={p.industry}
                gradient={p.gradient}
              />
            ))}
          </div>
        </Reveal>
      </section>

      <Reveal>
        <section className="py-28 bg-charcoal text-ivory">
          <div className="max-w-[1180px] mx-auto px-8">
            <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
              Process
            </span>
            <h2 className="font-display font-light text-[32px] md:text-[48px] max-w-[600px] mb-16 tracking-tight">
              Four stages, one standard — never rushed, never generic.
            </h2>
            <div className="grid md:grid-cols-4 gap-px bg-ivory/10">
              {[
                ["01", "Discovery", "Understanding the brand, the audience, and the feeling we're building toward."],
                ["02", "Strategy", "Positioning, tone, and the emotional direction that shapes every decision after."],
                ["03", "Design", "Identity, typography, and system — built with intention, refined without limit."],
                ["04", "Delivery", "Files, guidelines, and a brand ready to command premium attention."],
              ].map(([num, title, desc]) => (
                <div key={num} className="bg-charcoal p-8 transition-colors duration-400 hover:bg-[#242019]">
                  <span className="font-mono text-[11px] text-gold tracking-wider block mb-5">{num}</span>
                  <h5 className="font-display text-lg mb-2.5">{title}</h5>
                  <p className="text-[13px] text-ivory/60 leading-relaxed">{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </Reveal>

      <Reveal>
        <section className="py-24 border-b border-line">
          <div className="max-w-[1180px] mx-auto px-8 grid md:grid-cols-[200px_1fr] gap-14 items-start">
            <span className="font-mono text-xs uppercase tracking-widest text-gold">
              Beyond Client Work
            </span>
            <Link href="/what-if" className="group block">
              <h2 className="font-display text-[26px] md:text-[38px] leading-tight tracking-tight max-w-[640px] mb-4 transition-colors duration-300 group-hover:text-gold">
                What if Apple opened a hotel? What if Rolex made coffee?
              </h2>
              <span className="font-mono text-[11px] uppercase tracking-wider border-b border-charcoal pb-0.5 transition-colors duration-300 group-hover:border-gold group-hover:text-gold">
                Explore the &ldquo;What If?&rdquo; series →
              </span>
            </Link>
          </div>
        </section>
      </Reveal>

      <section className="max-w-[1180px] mx-auto px-8 py-32 md:py-36 text-center">
        <Reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
            Book a Project
          </span>
        </Reveal>
        <Reveal delay={0.1}>
          <h2 className="font-display font-light text-[38px] md:text-[72px] leading-tight tracking-tight mb-11">
            Let&rsquo;s build something
            <br />
            <em className="italic text-gold">unforgettable.</em>
          </h2>
        </Reveal>
        <Reveal delay={0.22}>
          <div className="flex justify-center">
            <Button href="/book" variant="primary">Start Your Project</Button>
          </div>
        </Reveal>
      </section>

      <Footer quote="Perception creates value." />
    </>
  );
}
