import type { Metadata } from "next";
import Link from "next/link";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import HiddenMark from "@/components/HiddenMark";
import { materials } from "@/lib/materials";

export const metadata: Metadata = {
  title: "Studio Novelle — Material Library",
  description: "The materials behind Studio Novelle's work — and why each one earns its place.",
};

export default function Materials() {
  return (
    <>
      <Nav />

      <header className="max-w-[1180px] mx-auto px-8 pt-32 md:pt-36 pb-16">
        <Reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
            Material Library<HiddenMark id="materials" />
          </span>
        </Reveal>
        <Reveal delay={0.1}>
          <h1 className="font-display font-light text-[38px] md:text-[76px] leading-[1.05] tracking-tight max-w-[780px] mb-7">
            We sell materials as much as colors.
          </h1>
        </Reveal>
        <Reveal delay={0.22}>
          <p className="text-stone text-base max-w-[480px] leading-relaxed">
            Every project draws from the same restrained set — not
            because variety is bad, but because restraint is what
            makes a brand feel considered rather than decorated.
          </p>
        </Reveal>
      </header>

      <section className="max-w-[1180px] mx-auto px-8 pb-28 border-t border-line">
        {materials.map((m, i) => (
          <Reveal key={m.slug} delay={(i % 3) * 0.08}>
            <div className="grid md:grid-cols-[280px_1fr] gap-10 md:gap-16 py-14 border-b border-line items-start">
              <div>
                <span className="font-mono text-xs text-gold tracking-wider block mb-5">
                  {m.num}
                </span>
                <div className="h-40" style={{ background: m.gradient }} />
                <span className="font-mono text-[10px] uppercase tracking-wider text-stone block mt-4">
                  {m.category}
                </span>
              </div>
              <div>
                <h2 className="font-display text-[26px] md:text-[34px] tracking-tight mb-4">
                  {m.name}
                </h2>
                <p className="text-base leading-relaxed text-stone max-w-[560px] mb-6">
                  {m.description}
                </p>
                {m.usedIn.length > 0 ? (
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="font-mono text-[10px] uppercase tracking-wider text-stone">
                      Used in
                    </span>
                    {m.usedIn.map((p) => (
                      <Link
                        key={p.slug}
                        href={`/work/${p.slug}`}
                        className="font-mono text-[11px] uppercase tracking-wider border border-line px-3 py-1.5 transition-colors duration-300 hover:border-gold hover:text-gold"
                      >
                        {p.name}
                      </Link>
                    ))}
                  </div>
                ) : (
                  <span className="font-mono text-[10px] uppercase tracking-wider text-stone">
                    Reserved for an upcoming project
                  </span>
                )}
              </div>
            </div>
          </Reveal>
        ))}
      </section>

      <Footer quote="Every detail communicates." />
    </>
  );
}
