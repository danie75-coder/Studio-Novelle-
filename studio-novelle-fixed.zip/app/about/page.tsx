import type { Metadata } from "next";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import Button from "@/components/Button";
import HiddenMark from "@/components/HiddenMark";

export const metadata: Metadata = {
  title: "Studio Novelle — Manifesto",
  description: "We don't decorate brands. We build desire.",
};

const beliefs = [
  "We believe first impressions shape opportunity.",
  "We believe luxury is a feeling, not a price.",
  "We believe every detail communicates.",
  "We believe silence is stronger than noise.",
  "We believe restraint creates confidence.",
  "We believe beauty should solve problems.",
];

export default function About() {
  return (
    <>
      <Nav active="/about" />

      <header className="max-w-[1180px] mx-auto px-8 pt-32 md:pt-36 pb-20">
        <Reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
            Manifesto
          </span>
        </Reveal>
        <Reveal delay={0.1}>
          <h1 className="font-display font-light text-[38px] md:text-[80px] leading-[1.08] tracking-tight max-w-[920px]">
            We don&rsquo;t decorate brands.
            <br />
            <span className="italic font-normal text-stone">We build desire.</span>
          </h1>
        </Reveal>
      </header>

      <section className="max-w-[1180px] mx-auto px-8 py-10 pb-32 border-t border-b border-line">
        {beliefs.map((b, i) => (
          <Reveal key={b} delay={(i % 3) * 0.1}>
            <div
              className={`grid grid-cols-[50px_1fr] md:grid-cols-[80px_1fr] gap-5 md:gap-8 items-baseline py-8 group ${
                i !== 0 ? "border-t border-line" : ""
              }`}
            >
              <span className="font-mono text-xs text-gold tracking-wider">
                0{i + 1}
              </span>
              <span className="font-display text-2xl md:text-[32px] leading-snug tracking-tight transition-all duration-400 group-hover:text-gold group-hover:pl-2.5">
                {b}
              </span>
            </div>
          </Reveal>
        ))}
      </section>

      <Reveal>
        <section className="max-w-[1180px] mx-auto px-8 py-28 grid md:grid-cols-[200px_1fr] gap-14">
          <span className="font-mono text-xs uppercase tracking-widest text-gold">
            The Studio<HiddenMark id="about" />
          </span>
          <div className="space-y-6">
            <p className="text-[19px] leading-relaxed max-w-[640px]">
              Studio Novelle exists for one reason — to help ambitious brands
              become unforgettable. Not louder. Not trendier. Unforgettable,
              the way a well-tailored room is unforgettable: nothing
              shouting, everything considered.
            </p>
            <p className="text-[19px] leading-relaxed max-w-[640px] text-stone">
              Every project starts the same way — not with a mood board, but
              with a single question: what should people feel in the first
              three seconds? The typography, the palette, the pacing of a
              scroll — all of it follows from that answer.
            </p>
          </div>
        </section>
      </Reveal>

      <Reveal>
        <section className="max-w-[1180px] mx-auto px-8 py-28 border-t border-line">
          <div className="grid md:grid-cols-[200px_1fr] gap-14 mb-14">
            <span className="font-mono text-xs uppercase tracking-widest text-gold">
              Studio Timeline
            </span>
            <p className="text-stone text-base leading-relaxed max-w-[560px]">
              Not a founding date — a record of what the studio has
              built, in the order it built it.
            </p>
          </div>
          <div className="grid md:grid-cols-5 gap-px bg-line border border-line">
            {[
              ["Research", "Material and typography studies, before a single client existed."],
              ["Experiments", "The first concept brand: Hollow Moon."],
              ["Concepts", "The archive expands — Veloura Parfum, then Aurelia Hotels."],
              ["Client Work", "Fixed-price services and custom branding projects open to the public."],
              ["Ongoing", "The Concept Archive keeps growing alongside client work, not instead of it."],
            ].map(([title, desc], i) => (
              <div key={title} className="bg-ivory p-7 transition-colors duration-400 hover:bg-beige">
                <span className="font-mono text-[11px] text-gold tracking-wider block mb-5">
                  0{i + 1}
                </span>
                <h4 className="font-display text-lg mb-2.5">{title}</h4>
                <p className="text-[13px] text-stone leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </section>
      </Reveal>

      <Reveal>
        <section className="py-28 bg-charcoal text-ivory text-center">
          <div className="max-w-[1180px] mx-auto px-8">
            <div className="w-[88px] h-[88px] mx-auto mb-10 rounded-full border border-gold flex items-center justify-center font-display text-3xl text-gold">
              N
            </div>
            <p className="font-display italic text-2xl md:text-[32px] max-w-[640px] mx-auto leading-snug">
              &ldquo;Perception creates value — before a single word is read,
              before a single product is sold.&rdquo;
            </p>
          </div>
        </section>
      </Reveal>

      <section className="max-w-[1180px] mx-auto px-8 py-32 md:py-36 text-center">
        <Reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
            Work With Us
          </span>
        </Reveal>
        <Reveal delay={0.1}>
          <h2 className="font-display font-light text-[38px] md:text-[72px] leading-tight tracking-tight mb-11">
            Let&rsquo;s build something
            <br />
            <em className="italic text-gold">unforgettable.</em>
          </h2>
        </Reveal>
        <Reveal delay={0.22}>
          <div className="flex justify-center">
            <Button href="/book" variant="primary">Book a Project</Button>
          </div>
        </Reveal>
      </section>

      <Footer quote="Restraint creates confidence." />
    </>
  );
}
