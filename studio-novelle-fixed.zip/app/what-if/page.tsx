import type { Metadata } from "next";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import HiddenMark from "@/components/HiddenMark";
import { whatIfConcepts } from "@/lib/whatIf";

export const metadata: Metadata = {
  title: "Studio Novelle — What If?",
  description: "Speculative branding explorations — what happens when familiar names enter unfamiliar categories.",
};

export default function WhatIf() {
  return (
    <>
      <Nav />

      <header className="max-w-[1180px] mx-auto px-8 pt-32 md:pt-36 pb-16">
        <Reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
            What If?
          </span>
        </Reveal>
        <Reveal delay={0.1}>
          <h1 className="font-display font-light text-[38px] md:text-[76px] leading-[1.05] tracking-tight max-w-[840px] mb-7">
            Familiar names, unfamiliar categories.
          </h1>
        </Reveal>
        <Reveal delay={0.22}>
          <p className="text-stone text-base max-w-[480px] leading-relaxed">
            Not client work — speculative branding exercises. Each one
            asks what happens when a brand&rsquo;s existing discipline
            gets pointed at a category it&rsquo;s never touched.
          </p>
        </Reveal>
      </header>

      <section className="max-w-[1180px] mx-auto px-8 pb-28">
        {whatIfConcepts.map((c, i) => (
          <Reveal key={c.slug} delay={(i % 2) * 0.1}>
            <div className="grid md:grid-cols-[1fr_1.4fr] gap-10 md:gap-16 py-16 border-t border-line group">
              <div>
                <span className="font-mono text-xs text-gold tracking-wider block mb-6">
                  Exploration — {c.num}
                </span>
                <div
                  className="h-56 mb-6 transition-transform duration-500 ease-studio group-hover:scale-[1.02]"
                  style={{ background: c.gradient }}
                />
                <p className="font-mono text-[10px] uppercase tracking-wider text-stone">
                  {c.industry}
                </p>
              </div>
              <div>
                <h2 className="font-display text-[26px] md:text-[38px] leading-tight tracking-tight mb-4">
                  {c.premise}
                </h2>
                <p className="font-display italic text-lg text-olive mb-6">
                  &ldquo;{c.tagline}&rdquo;
                </p>
                <p className="text-base leading-relaxed text-stone max-w-[520px]">
                  {c.concept}
                </p>
              </div>
            </div>
          </Reveal>
        ))}
      </section>

      <Reveal>
        <section className="py-28 bg-charcoal text-ivory text-center">
          <div className="max-w-[1180px] mx-auto px-8">
            <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
              Your Turn<HiddenMark id="what-if" />
            </span>
            <p className="font-display italic text-2xl md:text-[32px] max-w-[640px] mx-auto leading-snug">
              &ldquo;If we can build entire brand worlds from a single
              question, imagine what we can do for one that already
              exists.&rdquo;
            </p>
          </div>
        </section>
      </Reveal>

      <Footer quote="Beauty should solve problems." />
    </>
  );
}
