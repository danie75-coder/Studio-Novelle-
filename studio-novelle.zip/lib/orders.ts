import { getSupabaseAdmin } from "./supabase";
import { sendOrderConfirmationToClient, sendOrderNotificationToStudio } from "./email";

type PaidOrder = {
  reference: string;
  amountNaira: number;
  currency: string;
  customerEmail: string;
  customerName: string;
  serviceTitle: string;
  serviceSlug: string;
  metadata: Record<string, unknown>;
};

/**
 * Idempotent-ish entry point for a confirmed Paystack payment.
 * Called from both the client-triggered /verify route (for instant
 * UI feedback) and the /webhook route (the real source of truth).
 * When Supabase is configured, we check for an existing row first so
 * a payment confirmed by both paths only sends emails once. Without
 * Supabase there's no way to dedupe — see README.
 */
export async function recordPaidOrder(order: PaidOrder) {
  const supabase = getSupabaseAdmin();
  let alreadyRecorded = false;

  if (supabase) {
    const { data: existing } = await supabase
      .from("orders")
      .select("reference")
      .eq("reference", order.reference)
      .maybeSingle();

    alreadyRecorded = !!existing;

    const { error } = await supabase.from("orders").upsert(
      {
        reference: order.reference,
        status: "paid",
        service_slug: order.serviceSlug,
        service_title: order.serviceTitle,
        customer_name: order.customerName,
        customer_email: order.customerEmail,
        amount_naira: order.amountNaira,
        currency: order.currency,
        metadata: order.metadata,
      },
      { onConflict: "reference" }
    );
    if (error) {
      console.error("Failed to write order to Supabase:", error);
    }
  } else {
    console.warn(
      "SUPABASE_URL/SUPABASE_SERVICE_ROLE_KEY not set — order was not persisted, and duplicate emails cannot be deduped across verify + webhook."
    );
  }

  if (alreadyRecorded) {
    return { alreadyRecorded: true };
  }

  try {
    await sendOrderConfirmationToClient({
      toEmail: order.customerEmail,
      customerName: order.customerName,
      serviceTitle: order.serviceTitle,
      amountNaira: order.amountNaira,
      reference: order.reference,
    });
  } catch (e) {
    console.error("Failed to send client confirmation email:", e);
  }

  try {
    await sendOrderNotificationToStudio({
      serviceTitle: order.serviceTitle,
      customerName: order.customerName,
      customerEmail: order.customerEmail,
      amountNaira: order.amountNaira,
      reference: order.reference,
    });
  } catch (e) {
    console.error("Failed to send studio notification email:", e);
  }

  return { alreadyRecorded: false };
}
