export type Project = {
  slug: string;
  fileNo: string;
  name: string;
  industry: string;
  client: string;
  objective: string;
  status: "Completed" | "In Progress" | "Concept";
  gradient: string;
  plateLabel: string;
  challenge: { title: string; body: string };
  approach: { title: string; body: string; materials: string[] };
  work: { title: string; body: string };
  decision: string;
  dna: [string, number][];
};

export const projects: Project[] = [
  {
    slug: "hollow-moon",
    fileNo: "001",
    name: "Hollow Moon",
    industry: "Luxury Skincare",
    client: "Confidential",
    objective: "Turn a clinical category into a ritual",
    status: "Concept",
    gradient: "linear-gradient(135deg, #E9DFCC, #83786A 150%)",
    plateLabel: "Plate 01 — Packaging System",
    challenge: {
      title: "Skincare shelves read as clinical, not desirable.",
      body: "Most skincare packaging borrows from pharmacy shelving — sterile whites, clipped sans serifs, ingredient lists as decoration. That language builds trust but never desire. Hollow Moon needed both.",
    },
    approach: {
      title: "Ritual, not routine.",
      body: "We slowed the whole system down — soft-touch matte jars, a moon-phase motif used sparingly as a structural device rather than a gimmick, and copy written like an evening ritual instead of a product label.",
      materials: ["Frosted Glass", "Raw Linen", "Soft-Touch Matte", "Natural Stone"],
    },
    work: {
      title: "One identity, from jar to journal.",
      body: "Packaging, an unboxing sequence, and a companion journal insert all carry the same restrained mark and moon-phase system.",
    },
    decision:
      "We removed the ingredient list from the front of the packaging entirely — it now lives inside, so the first impression is calm, not clinical.",
    dna: [
      ["Luxury", 4],
      ["Minimal", 5],
      ["Bold", 2],
      ["Timeless", 4],
      ["Playful", 1],
    ],
  },
  {
    slug: "veloura",
    fileNo: "002",
    name: "Veloura Parfum",
    industry: "Luxury Fragrance",
    client: "Confidential",
    objective: "Create desire before the first spray",
    status: "Completed",
    gradient: "linear-gradient(135deg, rgba(176,141,83,0.14), #E9DFCC 150%)",
    plateLabel: "Plate 01 — Primary Mark",
    challenge: {
      title: "Fragrance shelves are crowded with the same language.",
      body: "Gold foil, cursive scripts, glass bottles lit like jewelry — every luxury fragrance brand was reaching for the same visual shorthand. Veloura needed to feel expensive without borrowing anyone else's version of expensive.",
    },
    approach: {
      title: "Confidence over decoration.",
      body: "We stripped the identity down until only what mattered remained — a single typographic mark, one restrained color story, and a bottle shape that reads as sculpture rather than packaging. Every embellishment we removed made the brand feel more expensive, not less.",
      materials: ["Frosted Glass", "Brushed Brass", "Matte Finish", "Wax Seal"],
    },
    work: {
      title: "Identity, packaging, and campaign — one language throughout.",
      body: "From the primary mark to the shelf display, nothing was designed in isolation.",
    },
    decision:
      "We chose a matte bottle because glossy packaging reflected too much light and reduced the premium feel.",
    dna: [
      ["Luxury", 5],
      ["Minimal", 5],
      ["Bold", 3],
      ["Timeless", 5],
      ["Playful", 1],
    ],
  },
  {
    slug: "aurelia-hotels",
    fileNo: "003",
    name: "Aurelia Hotels",
    industry: "Hospitality",
    client: "Confidential",
    objective: "Make a first-time guest feel like a returning one",
    status: "In Progress",
    gradient: "linear-gradient(135deg, #cdd3bc, #E9DFCC 150%)",
    plateLabel: "Plate 01 — Signage System",
    challenge: {
      title: "Boutique hotels default to 'warm,' which reads as generic.",
      body: "Rattan, string lights, and hand-lettered welcome signs are the default vocabulary for 'boutique.' Aurelia needed to feel considered enough for a design-literate guest, without feeling cold.",
    },
    approach: {
      title: "Quiet confidence, room by room.",
      body: "A single serif carries every touchpoint, from the key card to the room directory. Color shifts subtly by property rather than changing the system — the brand stays recognizable everywhere it appears.",
      materials: ["Natural Stone", "Brushed Brass", "Linen", "Frosted Glass"],
    },
    work: {
      title: "One brand, every touchpoint.",
      body: "Signage, key cards, in-room collateral, and the booking site all share the same typographic and material language.",
    },
    decision:
      "We replaced the lobby's illuminated signage with engraved brass — lit only by ambient light — because a glowing sign read as a hotel chain, not a private residence.",
    dna: [
      ["Luxury", 5],
      ["Minimal", 4],
      ["Bold", 2],
      ["Timeless", 5],
      ["Playful", 1],
    ],
  },
];

export function getProject(slug: string) {
  return projects.find((p) => p.slug === slug);
}

export function getNextProject(slug: string) {
  const i = projects.findIndex((p) => p.slug === slug);
  return projects[(i + 1) % projects.length];
}
