import { getSupabaseAdmin } from "./supabase";

export type Quote = {
  id: string;
  client_name: string | null;
  client_email: string;
  service_title: string;
  service_slug: string | null;
  total_naira: number;
  deposit_naira: number;
  balance_naira: number;
  deposit_paid: boolean;
  deposit_reference: string | null;
  balance_paid: boolean;
  balance_reference: string | null;
  created_at: string;
};

export async function createQuote(input: {
  clientName: string;
  clientEmail: string;
  serviceTitle: string;
  serviceSlug?: string;
  totalNaira: number;
}) {
  const supabase = getSupabaseAdmin();
  if (!supabase) throw new Error("Supabase is not configured.");

  const depositNaira = Math.round(input.totalNaira * 0.5);
  const balanceNaira = input.totalNaira - depositNaira;

  const { data, error } = await supabase
    .from("quotes")
    .insert({
      client_name: input.clientName,
      client_email: input.clientEmail,
      service_title: input.serviceTitle,
      service_slug: input.serviceSlug ?? null,
      total_naira: input.totalNaira,
      deposit_naira: depositNaira,
      balance_naira: balanceNaira,
    })
    .select()
    .single();

  if (error) throw error;
  return data as Quote;
}

export async function getQuote(id: string): Promise<Quote | null> {
  const supabase = getSupabaseAdmin();
  if (!supabase) return null;

  const { data, error } = await supabase
    .from("quotes")
    .select("*")
    .eq("id", id)
    .maybeSingle();

  if (error) {
    console.error("Failed to fetch quote:", error);
    return null;
  }
  return data as Quote | null;
}

export async function markQuoteStagePaid(
  id: string,
  stage: "deposit" | "balance",
  reference: string
) {
  const supabase = getSupabaseAdmin();
  if (!supabase) throw new Error("Supabase is not configured.");

  const update =
    stage === "deposit"
      ? { deposit_paid: true, deposit_reference: reference }
      : { balance_paid: true, balance_reference: reference };

  const { data, error } = await supabase
    .from("quotes")
    .update(update)
    .eq("id", id)
    .select()
    .single();

  if (error) throw error;
  return data as Quote;
}
