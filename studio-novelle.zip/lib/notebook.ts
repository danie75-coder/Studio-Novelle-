export type Note = {
  num: string;
  slug: string;
  title: string;
  excerpt: string;
  body: string[];
};

export const notes: Note[] = [
  {
    num: "001",
    slug: "negative-space",
    title: "Why Luxury Brands Love Negative Space",
    excerpt: "Empty space isn't unfinished — it's confidence. The more a brand has to say, the less room it usually needs.",
    body: [
      "Cheap design fills every inch. It's an instinct — if the space is empty, something must be missing. Luxury design does the opposite: it treats space as the most expensive material on the page.",
      "Negative space signals that a brand isn't trying to convince you of anything. A crowded layout argues its case. A quiet one assumes you're already listening.",
      "This is why the whitespace around a logo often costs more design hours than the logo itself — the ratio between mark and margin is the actual decision. Get it wrong, and confidence reads as absence instead of restraint.",
    ],
  },
  {
    num: "002",
    slug: "typography-trust",
    title: "Why Typography Creates Trust",
    excerpt: "Before anyone reads a word, the letterforms have already told them how much to believe.",
    body: [
      "Typography is read before it's read. The weight, the spacing, the contrast between thick and thin strokes — all of it lands as a feeling before the words register as meaning.",
      "A high-contrast serif, the kind with dramatic thin strokes, reads as edited and considered — someone chose every stroke on purpose. A default system sans reads as unconsidered, even when the writing underneath it is excellent.",
      "This is why one typeface, used with total discipline, builds more trust than five typefaces used well. Consistency is what the eye reads as competence.",
    ],
  },
  {
    num: "003",
    slug: "packaging-desire",
    title: "How Packaging Creates Desire",
    excerpt: "The unboxing happens before the box is opened — weight, resistance, and sound do most of the persuading.",
    body: [
      "Desire is built before a product is used. It's built in the seconds between picking something up and opening it — the weight in the hand, the resistance of a lid, the sound a box makes when it closes.",
      "Matte over gloss. Rigid over flimsy. A slight resistance when opening, rather than a lid that falls off. None of these affect the product inside, but all of them affect how premium the product feels before it's even seen.",
      "Packaging is the only part of a brand that a customer touches before they decide to trust it. That makes it one of the most persuasive surfaces a studio can design.",
    ],
  },
];

export function getNote(slug: string) {
  return notes.find((n) => n.slug === slug);
}
