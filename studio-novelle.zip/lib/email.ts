import { Resend } from "resend";

const FROM = "Studio Novelle <inquiries@studionovelle.com>";

function getResend() {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) return null;
  return new Resend(apiKey);
}

export async function sendOrderConfirmationToClient(opts: {
  toEmail: string;
  customerName: string;
  serviceTitle: string;
  amountNaira: number;
  reference: string;
}) {
  const resend = getResend();
  if (!resend) {
    console.warn("RESEND_API_KEY not set — skipping client confirmation email");
    return;
  }

  await resend.emails.send({
    from: FROM,
    to: opts.toEmail,
    subject: `Payment Confirmed — ${opts.serviceTitle}`,
    text: [
      `Hi ${opts.customerName || "there"},`,
      "",
      `Your payment for ${opts.serviceTitle} has been confirmed.`,
      "",
      `Amount paid: ₦${opts.amountNaira.toLocaleString()}`,
      `Reference: ${opts.reference}`,
      "",
      "We'll follow up within one business day with your creative brief",
      "questionnaire and next steps.",
      "",
      "— Studio Novelle",
    ].join("\n"),
  });
}

export async function sendOrderNotificationToStudio(opts: {
  serviceTitle: string;
  customerName: string;
  customerEmail: string;
  amountNaira: number;
  reference: string;
}) {
  const resend = getResend();
  const toEmail = process.env.CONTACT_TO_EMAIL;

  if (!resend || !toEmail) {
    console.warn("RESEND_API_KEY or CONTACT_TO_EMAIL not set — skipping studio notification email");
    return;
  }

  await resend.emails.send({
    from: FROM,
    to: toEmail,
    subject: `New Paid Order — ${opts.serviceTitle}`,
    text: [
      `Service: ${opts.serviceTitle}`,
      `Amount: ₦${opts.amountNaira.toLocaleString()}`,
      `Client: ${opts.customerName || "—"} <${opts.customerEmail}>`,
      `Reference: ${opts.reference}`,
    ].join("\n"),
  });
}

export async function sendQuoteLinkToClient(opts: {
  toEmail: string;
  clientName: string;
  serviceTitle: string;
  totalNaira: number;
  depositNaira: number;
  checkoutUrl: string;
}) {
  const resend = getResend();
  if (!resend) {
    console.warn("RESEND_API_KEY not set — skipping quote link email");
    return;
  }

  await resend.emails.send({
    from: FROM,
    to: opts.toEmail,
    subject: `Your Studio Novelle Quote — ${opts.serviceTitle}`,
    text: [
      `Hi ${opts.clientName || "there"},`,
      "",
      `Here's your project quote for ${opts.serviceTitle}.`,
      "",
      `Total project cost: ₦${opts.totalNaira.toLocaleString()}`,
      `Deposit due to begin: ₦${opts.depositNaira.toLocaleString()} (50%)`,
      `Remaining balance: due before final delivery`,
      "",
      `Pay your deposit here: ${opts.checkoutUrl}`,
      "",
      "— Studio Novelle",
    ].join("\n"),
  });
}

export async function sendQuoteStagePaidToClient(opts: {
  toEmail: string;
  clientName: string;
  serviceTitle: string;
  stage: "deposit" | "balance";
  amountNaira: number;
}) {
  const resend = getResend();
  if (!resend) {
    console.warn("RESEND_API_KEY not set — skipping quote payment confirmation email");
    return;
  }

  const isDeposit = opts.stage === "deposit";

  await resend.emails.send({
    from: FROM,
    to: opts.toEmail,
    subject: isDeposit
      ? `Deposit Confirmed — ${opts.serviceTitle}`
      : `Final Payment Confirmed — ${opts.serviceTitle}`,
    text: [
      `Hi ${opts.clientName || "there"},`,
      "",
      isDeposit
        ? `Your deposit of ₦${opts.amountNaira.toLocaleString()} for ${opts.serviceTitle} has been received. We're getting started.`
        : `Your final payment of ₦${opts.amountNaira.toLocaleString()} for ${opts.serviceTitle} has been received. Thank you for working with us.`,
      "",
      "— Studio Novelle",
    ].join("\n"),
  });
}

export async function sendQuoteStagePaidToStudio(opts: {
  serviceTitle: string;
  clientName: string;
  clientEmail: string;
  stage: "deposit" | "balance";
  amountNaira: number;
}) {
  const resend = getResend();
  const toEmail = process.env.CONTACT_TO_EMAIL;

  if (!resend || !toEmail) {
    console.warn("RESEND_API_KEY or CONTACT_TO_EMAIL not set — skipping studio quote notification email");
    return;
  }

  await resend.emails.send({
    from: FROM,
    to: toEmail,
    subject: `${opts.stage === "deposit" ? "Deposit" : "Final Payment"} Received — ${opts.serviceTitle}`,
    text: [
      `Service: ${opts.serviceTitle}`,
      `Stage: ${opts.stage}`,
      `Amount: ₦${opts.amountNaira.toLocaleString()}`,
      `Client: ${opts.clientName || "—"} <${opts.clientEmail}>`,
    ].join("\n"),
  });
}
