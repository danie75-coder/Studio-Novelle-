import { getQuote, markQuoteStagePaid } from "./quotes";
import { getSupabaseAdmin } from "./supabase";
import { sendQuoteStagePaidToClient, sendQuoteStagePaidToStudio } from "./email";

/**
 * The quote equivalent of recordPaidOrder() in lib/orders.ts — shared
 * by the client-triggered /api/quotes/[id]/pay route AND the
 * Paystack/Flutterwave webhooks, so a quote payment is recorded
 * correctly no matter which path notices it first. Idempotent: if
 * the stage is already marked paid, it skips re-writing and
 * re-emailing.
 */
export async function recordQuoteStagePayment(opts: {
  quoteId: string;
  stage: "deposit" | "balance";
  reference: string;
  amountNaira: number;
  clientEmail: string;
  clientName: string;
}) {
  const quote = await getQuote(opts.quoteId);
  if (!quote) {
    throw new Error(`Quote ${opts.quoteId} not found`);
  }

  const alreadyPaid = opts.stage === "deposit" ? quote.deposit_paid : quote.balance_paid;
  if (alreadyPaid) {
    return { alreadyRecorded: true, quote };
  }

  if (opts.stage === "balance" && !quote.deposit_paid) {
    // Shouldn't happen in practice (the checkout page won't offer a
    // balance payment before the deposit), but guard against a stray
    // or out-of-order webhook delivery anyway.
    throw new Error(`Quote ${opts.quoteId} balance paid before deposit`);
  }

  const updatedQuote = await markQuoteStagePaid(opts.quoteId, opts.stage, opts.reference);

  const supabase = getSupabaseAdmin();
  if (supabase) {
    const { error } = await supabase.from("orders").upsert(
      {
        reference: opts.reference,
        status: opts.stage === "deposit" ? "deposit_paid" : "balance_paid",
        service_slug: quote.service_slug,
        service_title: quote.service_title,
        customer_name: opts.clientName || quote.client_name,
        customer_email: opts.clientEmail || quote.client_email,
        amount_naira: opts.amountNaira,
        currency: "NGN",
        metadata: { quote_id: quote.id, stage: opts.stage },
      },
      { onConflict: "reference" }
    );
    if (error) console.error("Failed to write quote payment to orders:", error);
  }

  try {
    await sendQuoteStagePaidToClient({
      toEmail: opts.clientEmail || quote.client_email,
      clientName: opts.clientName || quote.client_name || "",
      serviceTitle: quote.service_title,
      stage: opts.stage,
      amountNaira: opts.amountNaira,
    });
  } catch (e) {
    console.error("Failed to send client quote payment email:", e);
  }

  try {
    await sendQuoteStagePaidToStudio({
      serviceTitle: quote.service_title,
      clientName: opts.clientName || quote.client_name || "",
      clientEmail: opts.clientEmail || quote.client_email,
      stage: opts.stage,
      amountNaira: opts.amountNaira,
    });
  } catch (e) {
    console.error("Failed to send studio quote payment notification:", e);
  }

  return { alreadyRecorded: false, quote: updatedQuote };
}
