import { getSupabaseAdmin } from "./supabase";

function getAllowedAdminEmails(): string[] {
  return (process.env.ADMIN_EMAILS || "")
    .split(",")
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
}

/**
 * Verifies the bearer token in an API request against Supabase Auth,
 * then checks the resulting email against ADMIN_EMAILS (server-only —
 * never exposed to the client). Returns the admin's email if both
 * checks pass, or null otherwise. This is the real enforcement point;
 * anything client-side (e.g. hiding UI in /admin/quotes) is just UX.
 */
export async function requireAdmin(req: Request): Promise<{ email: string } | null> {
  const authHeader = req.headers.get("authorization");
  const token = authHeader?.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) return null;

  const supabase = getSupabaseAdmin();
  if (!supabase) return null;

  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data?.user?.email) return null;

  const email = data.user.email.toLowerCase();
  const allowed = getAllowedAdminEmails();
  if (allowed.length === 0 || !allowed.includes(email)) return null;

  return { email };
}
