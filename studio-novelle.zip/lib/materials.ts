export type Material = {
  num: string;
  slug: string;
  name: string;
  category: string;
  description: string;
  gradient: string;
  usedIn: { name: string; slug: string }[];
};

export const materials: Material[] = [
  {
    num: "01",
    slug: "italian-marble",
    name: "Italian Marble",
    category: "Stone",
    description:
      "Veining that never repeats twice — the closest thing to a signature a material can have on its own. Used sparingly, and only where weight and permanence matter more than warmth.",
    gradient: "linear-gradient(135deg, #F6F1E7 0%, #E9DFCC 35%, #d9cdb5 55%, #E9DFCC 75%, #F6F1E7 100%)",
    usedIn: [],
  },
  {
    num: "02",
    slug: "brushed-brass",
    name: "Brushed Brass",
    category: "Metal",
    description:
      "Warmer than steel, quieter than gold. The brushing matters more than the metal — a mirror finish reads as costume jewelry; brushed reads as architecture.",
    gradient: "linear-gradient(135deg, #cbb37a 0%, #b08d53 30%, #cbb37a 55%, #967140 75%, #cbb37a 100%)",
    usedIn: [
      { name: "Veloura Parfum", slug: "veloura" },
      { name: "Aurelia Hotels", slug: "aurelia-hotels" },
    ],
  },
  {
    num: "03",
    slug: "raw-linen",
    name: "Raw Linen",
    category: "Textile",
    description:
      "Imperfect on purpose — the slubs and irregularities are what separate it from cotton twill. Used where a brand needs to feel handled rather than manufactured.",
    gradient: "linear-gradient(135deg, #EDE6D9 0%, #E9DFCC 40%, #ddd2ba 60%, #E9DFCC 100%)",
    usedIn: [
      { name: "Hollow Moon", slug: "hollow-moon" },
      { name: "Aurelia Hotels", slug: "aurelia-hotels" },
    ],
  },
  {
    num: "04",
    slug: "frosted-glass",
    name: "Frosted Glass",
    category: "Glass",
    description:
      "Clear glass shows you the product; frosted glass makes you imagine it. The diffusion does the work a label would otherwise have to do.",
    gradient: "linear-gradient(135deg, #F6F1E7 0%, #EDE6D9 50%, #F6F1E7 100%)",
    usedIn: [
      { name: "Hollow Moon", slug: "hollow-moon" },
      { name: "Veloura Parfum", slug: "veloura" },
      { name: "Aurelia Hotels", slug: "aurelia-hotels" },
    ],
  },
  {
    num: "05",
    slug: "velvet",
    name: "Velvet",
    category: "Textile",
    description:
      "The only material on this list that changes appearance depending on the angle it's viewed from — which is exactly why it's reserved for interiors and unboxing moments, never for anything meant to be photographed flat.",
    gradient: "linear-gradient(135deg, #6B7052 0%, #5B6146 40%, #6B7052 70%, #4a4f3a 100%)",
    usedIn: [],
  },
  {
    num: "06",
    slug: "natural-stone",
    name: "Natural Stone",
    category: "Stone",
    description:
      "Unpolished, unlike marble — the texture stays rough enough to feel quarried rather than manufactured. Grounds a brand that might otherwise feel too light.",
    gradient: "linear-gradient(135deg, #83786A 0%, #6f6558 35%, #83786A 60%, #948a7c 100%)",
    usedIn: [
      { name: "Hollow Moon", slug: "hollow-moon" },
      { name: "Aurelia Hotels", slug: "aurelia-hotels" },
    ],
  },
  {
    num: "07",
    slug: "matte-finish",
    name: "Matte Finish",
    category: "Surface Treatment",
    description:
      "Not a material so much as a decision — the single biggest lever for making anything feel more expensive than it costs. Glossy reflects the room; matte holds its own light.",
    gradient: "linear-gradient(135deg, #E9DFCC 0%, #ddd2ba 100%)",
    usedIn: [{ name: "Veloura Parfum", slug: "veloura" }],
  },
  {
    num: "08",
    slug: "wax-seal",
    name: "Wax Seal",
    category: "Detail",
    description:
      "The last thing touched before a product is used, and the first sign of care a customer notices. A small, deliberately imperfect detail in a system that's otherwise precise everywhere else.",
    gradient: "linear-gradient(135deg, #967140 0%, #B08D53 45%, #967140 80%)",
    usedIn: [{ name: "Veloura Parfum", slug: "veloura" }],
  },
];
