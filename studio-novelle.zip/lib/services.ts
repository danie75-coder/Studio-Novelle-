export type Service = {
  num: string;
  slug: string;
  title: string;
  description: string;
  fixedPrice: boolean;
  priceNaira: number | null; // null when quote-only
  priceLabel: string; // display label
};

export const services: Service[] = [
  {
    num: "01",
    slug: "brand-identity",
    title: "Brand Identity",
    description: "Full visual system — logo, typography, color, and guidelines built to hold up across every touchpoint.",
    fixedPrice: false,
    priceNaira: null,
    priceLabel: "Starting from ₦50,000",
  },
  {
    num: "02",
    slug: "creative-direction",
    title: "Creative Direction",
    description: "Ongoing creative oversight — keeping every asset, campaign, and touchpoint on-brand.",
    fixedPrice: false,
    priceNaira: null,
    priceLabel: "Request a Quote",
  },
  {
    num: "03",
    slug: "packaging-design",
    title: "Packaging Design",
    description: "Structure, materials, and print-ready artwork for products that need to feel premium in hand.",
    fixedPrice: false,
    priceNaira: null,
    priceLabel: "Request a Quote",
  },
  {
    num: "04",
    slug: "marketing-campaigns",
    title: "Marketing Campaigns",
    description: "Concept-to-execution campaigns across digital and print, built around one central idea.",
    fixedPrice: false,
    priceNaira: null,
    priceLabel: "Request a Quote",
  },
  {
    num: "05",
    slug: "linkedin-branding",
    title: "LinkedIn Branding",
    description: "Banner, profile system, and post templates that make a personal brand look institutional.",
    fixedPrice: true,
    priceNaira: 12000,
    priceLabel: "₦12,000",
  },
  {
    num: "06",
    slug: "social-media-design",
    title: "Social Media Design",
    description: "Templated post systems that stay consistent no matter who's publishing.",
    fixedPrice: true,
    priceNaira: 7500,
    priceLabel: "₦7,500",
  },
  {
    num: "07",
    slug: "advertising-design",
    title: "Advertising Design",
    description: "Static and motion ad creative built to stop the scroll without losing the brand's restraint.",
    fixedPrice: true,
    priceNaira: 15000,
    priceLabel: "₦15,000",
  },
  {
    num: "08",
    slug: "landing-pages",
    title: "Landing Pages",
    description: "Single-page sites built for launches, campaigns, or offers that need their own moment.",
    fixedPrice: false,
    priceNaira: null,
    priceLabel: "Request a Quote",
  },
  {
    num: "09",
    slug: "copywriting",
    title: "Copywriting",
    description: "Brand voice, taglines, and web copy written the way the rest of the identity looks.",
    fixedPrice: true,
    priceNaira: 7500,
    priceLabel: "₦7,500",
  },
];

export function getService(slug: string) {
  return services.find((s) => s.slug === slug);
}
