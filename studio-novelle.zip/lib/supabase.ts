import { createClient } from "@supabase/supabase-js";

// Server-only. Uses the service-role key, so this must never be
// imported into a "use client" component — API routes only.
export function getSupabaseAdmin() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !key) {
    return null;
  }

  return createClient(url, key, {
    auth: { persistSession: false },
  });
}
