export type WhatIfConcept = {
  num: string;
  slug: string;
  brand: string;
  premise: string; // "What if X made Y?"
  industry: string;
  tagline: string;
  concept: string;
  gradient: string;
};

export const whatIfConcepts: WhatIfConcept[] = [
  {
    num: "01",
    slug: "apple-hotel",
    brand: "Apple",
    premise: "What if Apple opened a hotel?",
    industry: "Hospitality",
    tagline: "Fewer rooms. Fewer choices. Everything considered twice.",
    concept:
      "No front desk — check-in happens before you arrive, on a device you already own. Rooms ship with exactly one lighting mode: right. The minibar is empty on purpose; the only thing waiting for you is silence, done well.",
    gradient: "linear-gradient(135deg, #E9DFCC, #83786A 150%)",
  },
  {
    num: "02",
    slug: "rolex-coffee",
    brand: "Rolex",
    premise: "What if Rolex opened a coffee company?",
    industry: "Specialty Coffee",
    tagline: "One roast. No seasonal menu. It doesn't need one.",
    concept:
      "A single blend, unchanged for a decade, sold in a tin heavy enough to double as a paperweight. No loyalty app — the reward for coming back is that it tastes exactly the same as it did the first time.",
    gradient: "linear-gradient(135deg, rgba(176,141,83,0.14), #E9DFCC 150%)",
  },
  {
    num: "03",
    slug: "netflix-perfume",
    brand: "Netflix",
    premise: "What if Netflix launched a perfume?",
    industry: "Luxury Fragrance",
    tagline: "A different scent every night. You never see the same one twice.",
    concept:
      "A subscription, not a bottle — a new fragrance profile algorithmically composed each week based on what you watched. The packaging changes too; the only constant is the mark on the cap.",
    gradient: "linear-gradient(135deg, #cdd3bc, #E9DFCC 150%)",
  },
  {
    num: "04",
    slug: "porsche-skincare",
    brand: "Porsche",
    premise: "What if Porsche built a skincare company?",
    industry: "Luxury Skincare",
    tagline: "Engineered, not formulated. Three products, not thirty.",
    concept:
      "A routine with the same restraint as a dashboard — nothing on the shelf that isn't earning its place. The bottles are aluminum, not glass, and machined rather than molded. Performance is stated in numbers, not adjectives.",
    gradient: "linear-gradient(135deg, #E9DFCC, #B08D53 150%)",
  },
];

export function getWhatIf(slug: string) {
  return whatIfConcepts.find((c) => c.slug === slug);
}
