"use client";

import { createClient } from "@supabase/supabase-js";

// Browser-side client, used only by /vault. Uses the public anon key
// (safe to expose) — access to a client's own rows is enforced by
// the RLS policies in supabase/schema.sql, not by this key.
let client: ReturnType<typeof createClient> | null = null;

export function getSupabaseBrowser() {
  if (client) return client;

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !anonKey) {
    console.warn("NEXT_PUBLIC_SUPABASE_URL/NEXT_PUBLIC_SUPABASE_ANON_KEY not set — /vault will not work.");
    return null;
  }

  client = createClient(url, anonKey);
  return client;
}
