-- Run this once in the Supabase SQL editor for your project.

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  reference text unique not null,
  status text not null,               -- 'paid' | 'deposit_paid' | 'balance_paid'
  service_slug text,
  service_title text,
  customer_name text,
  customer_email text not null,
  amount_naira numeric not null,
  currency text default 'NGN',
  metadata jsonb,
  created_at timestamptz default now()
);

create table if not exists quotes (
  id uuid primary key default gen_random_uuid(),
  client_name text,
  client_email text not null,
  service_title text not null,
  service_slug text,
  total_naira numeric not null,
  deposit_naira numeric not null,
  balance_naira numeric not null,
  deposit_paid boolean not null default false,
  deposit_reference text,
  balance_paid boolean not null default false,
  balance_reference text,
  created_at timestamptz default now()
);

-- Service-role key (used server-side only) bypasses RLS entirely, so
-- API routes using it can always read/write regardless of the
-- policies below. These policies only govern what a logged-in client
-- (using the anon/authenticated key from the browser, in /vault) can
-- see of their own data.

alter table orders enable row level security;
alter table quotes enable row level security;

create policy "clients can view their own orders"
  on orders for select
  using (customer_email = auth.jwt() ->> 'email');

create policy "clients can view their own quotes"
  on quotes for select
  using (client_email = auth.jwt() ->> 'email');

grant select on orders to authenticated;
grant select on quotes to authenticated;
