"use client";

import { useState } from "react";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";

const projectTypes = ["Brand Identity", "Packaging", "Marketing Campaign", "Social Media", "Landing Page", "Not Sure Yet"];
const budgets = ["₦10,000 – ₦25,000", "₦25,000 – ₦50,000", "₦50,000+"];

function ChipGroup({
  options,
  selected,
  onSelect,
}: {
  options: string[];
  selected: string | null;
  onSelect: (v: string) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2.5">
      {options.map((opt) => (
        <button
          type="button"
          key={opt}
          onClick={() => onSelect(opt)}
          className={`font-mono text-[11px] uppercase tracking-wide border px-4 py-2.5 transition-all duration-300 ${
            selected === opt
              ? "bg-charcoal text-ivory border-charcoal"
              : "border-line hover:border-gold hover:text-gold"
          }`}
        >
          {opt}
        </button>
      ))}
    </div>
  );
}

type Status = "idle" | "loading" | "success" | "error";

export default function Contact() {
  const [projectType, setProjectType] = useState<string | null>(null);
  const [budget, setBudget] = useState<string | null>(null);
  const [status, setStatus] = useState<Status>("idle");
  const [errorMsg, setErrorMsg] = useState<string>("");

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("loading");
    setErrorMsg("");

    const form = e.currentTarget;
    const data = {
      name: (form.elements.namedItem("name") as HTMLInputElement).value,
      email: (form.elements.namedItem("email") as HTMLInputElement).value,
      business: (form.elements.namedItem("business") as HTMLInputElement).value,
      projectType,
      budget,
      message: (form.elements.namedItem("message") as HTMLTextAreaElement).value,
    };

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const json = await res.json();

      if (!res.ok) {
        setStatus("error");
        setErrorMsg(json.error || "Something went wrong. Please try again.");
        return;
      }

      setStatus("success");
      form.reset();
      setProjectType(null);
      setBudget(null);
    } catch {
      setStatus("error");
      setErrorMsg("Something went wrong. Please try again.");
    }
  }

  return (
    <>
      <Nav />

      <div className="max-w-[1180px] mx-auto px-8 py-28 grid md:grid-cols-[1fr_1.15fr] gap-20">
        <Reveal>
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-7">
              Book a Project
            </span>
            <h1 className="font-display font-light text-[38px] md:text-[64px] leading-[1.06] tracking-tight mb-7">
              Let&rsquo;s start the right
              <br />
              project, <em className="italic text-gold font-normal">together.</em>
            </h1>
            <p className="text-stone text-base leading-relaxed max-w-[400px] mb-12">
              Tell us about your brand and what you&rsquo;re building.
              We&rsquo;ll follow up within one business day with next steps
              and availability. Prefer a live conversation first?{" "}
              <a href="/book" className="text-charcoal underline underline-offset-2 hover:text-gold">
                Reserve a discovery call
              </a>
              .
            </p>

            <div className="border-t border-line pt-8">
              {[
                ["Email", "hello@studionovelle.com", "mailto:hello@studionovelle.com"],
                ["WhatsApp", "Message the studio", "#"],
                ["Instagram", "@studionovelle", "#"],
              ].map(([label, value, href]) => (
                <div key={label} className="flex justify-between py-4 border-b border-line text-sm">
                  <span className="font-mono text-[10px] uppercase tracking-wider text-stone">{label}</span>
                  <a href={href} className="hover:text-gold transition-colors">{value}</a>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          {status === "success" ? (
            <div className="border border-line p-10 bg-beige">
              <span className="font-mono text-[10px] uppercase tracking-wider text-olive block mb-4">
                Received
              </span>
              <h3 className="font-display text-2xl mb-3">Thank you.</h3>
              <p className="text-stone text-sm leading-relaxed">
                Your project details are in. We&rsquo;ll follow up within one
                business day with next steps and availability.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-2 gap-7 mb-7">
                <div>
                  <label className="block font-mono text-[10px] uppercase tracking-wider text-stone mb-3">Your Name</label>
                  <input name="name" required type="text" placeholder="Full name" className="w-full border-0 border-b border-line bg-transparent py-3 text-[17px] focus:outline-none focus:border-gold transition-colors placeholder:text-stone/50" />
                </div>
                <div>
                  <label className="block font-mono text-[10px] uppercase tracking-wider text-stone mb-3">Email</label>
                  <input name="email" required type="email" placeholder="you@company.com" className="w-full border-0 border-b border-line bg-transparent py-3 text-[17px] focus:outline-none focus:border-gold transition-colors placeholder:text-stone/50" />
                </div>
              </div>

              <div className="mb-7">
                <label className="block font-mono text-[10px] uppercase tracking-wider text-stone mb-3">Business Name</label>
                <input name="business" type="text" placeholder="e.g. Maison Noir" className="w-full border-0 border-b border-line bg-transparent py-3 text-[17px] focus:outline-none focus:border-gold transition-colors placeholder:text-stone/50" />
              </div>

              <div className="mb-7">
                <label className="block font-mono text-[10px] uppercase tracking-wider text-stone mb-3">What Are You Looking For?</label>
                <ChipGroup options={projectTypes} selected={projectType} onSelect={setProjectType} />
              </div>

              <div className="mb-7">
                <label className="block font-mono text-[10px] uppercase tracking-wider text-stone mb-3">Budget Range</label>
                <ChipGroup options={budgets} selected={budget} onSelect={setBudget} />
              </div>

              <div className="mb-7">
                <label className="block font-mono text-[10px] uppercase tracking-wider text-stone mb-3">Tell Us About Your Project</label>
                <textarea name="message" required rows={4} placeholder="What are you building, and what should people feel when they see it?" className="w-full border-0 border-b border-line bg-transparent py-3 text-[17px] focus:outline-none focus:border-gold transition-colors resize-none placeholder:text-stone/50" />
              </div>

              <button
                type="submit"
                disabled={status === "loading"}
                className="mt-3 inline-flex items-center gap-2.5 font-sans text-[13px] font-semibold uppercase tracking-wider px-8 py-4 rounded-sm bg-charcoal text-ivory transition-all duration-500 ease-studio hover:bg-gold hover:text-charcoal hover:-translate-y-0.5 disabled:opacity-50 disabled:pointer-events-none"
              >
                {status === "loading" ? "Sending…" : "Send Project Details"}
              </button>

              {status === "error" && (
                <p className="mt-4 text-xs text-red-700">{errorMsg}</p>
              )}

              <p className="mt-4 text-xs text-stone leading-relaxed">
                Fixed-price services can be booked instantly. Larger branding
                projects receive a custom proposal before any payment.
              </p>
            </form>
          )}
        </Reveal>
      </div>

      <Footer quote="First impressions shape opportunity." />
    </>
  );
}
