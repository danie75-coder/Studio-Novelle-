import type { Metadata } from "next";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import CalEmbed from "@/components/CalEmbed";

export const metadata: Metadata = {
  title: "Studio Novelle — Reserve a Session",
  description: "Book a discovery call or strategy session with Studio Novelle.",
};

export default function Book() {
  return (
    <>
      <Nav />

      <header className="max-w-[1180px] mx-auto px-8 pt-32 md:pt-36 pb-16">
        <Reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
            Reserve a Session
          </span>
        </Reveal>
        <Reveal delay={0.1}>
          <h1 className="font-display font-light text-[38px] md:text-[72px] leading-[1.05] tracking-tight max-w-[820px] mb-7">
            Choose a date that works for you.
          </h1>
        </Reveal>
        <Reveal delay={0.22}>
          <p className="text-stone text-base max-w-[500px] leading-relaxed">
            We&rsquo;ll dedicate time to understanding your vision before
            design begins. Times shown adjust automatically to your local
            time zone. Prefer email first?{" "}
            <a href="/contact" className="text-charcoal underline underline-offset-2 hover:text-gold">
              Send us a project brief instead
            </a>
            .
          </p>
        </Reveal>
      </header>

      <Reveal>
        <section className="max-w-[1180px] mx-auto px-8 pb-28">
          <div className="border border-line bg-beige/40 min-h-[700px]">
            <CalEmbed />
          </div>
          <p className="mt-6 text-xs text-stone leading-relaxed">
            Booking is powered by Cal.com. Set{" "}
            <code className="font-mono">NEXT_PUBLIC_CAL_LINK</code> in your
            environment to your studio&rsquo;s real Cal.com event link once
            it&rsquo;s set up.
          </p>
        </section>
      </Reveal>

      <Footer quote="Perception creates value." />
    </>
  );
}
