"use client";

import { useEffect, useState } from "react";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import PaystackButton from "@/components/PaystackButton";
import FlutterwaveButton from "@/components/FlutterwaveButton";

type PublicQuote = {
  id: string;
  service_title: string;
  total_naira: number;
  deposit_naira: number;
  balance_naira: number;
  deposit_paid: boolean;
  balance_paid: boolean;
};

export default function QuoteCheckout({ params }: { params: { id: string } }) {
  const [quote, setQuote] = useState<PublicQuote | null | "not_found">(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "verifying" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    fetch(`/api/quotes/${params.id}`)
      .then((res) => (res.ok ? res.json() : Promise.reject()))
      .then(setQuote)
      .catch(() => setQuote("not_found"));
  }, [params.id]);

  async function pay(stage: "deposit" | "balance", processor: "paystack" | "flutterwave", ref: string) {
    setStatus("verifying");
    setErrorMsg("");
    try {
      const res = await fetch(`/api/quotes/${params.id}/pay`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          processor,
          stage,
          reference: processor === "paystack" ? ref : undefined,
          transactionId: processor === "flutterwave" ? ref : undefined,
          clientEmail: email,
          clientName: name,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Payment could not be confirmed.");

      setQuote((q) =>
        q && q !== "not_found"
          ? {
              ...q,
              deposit_paid: stage === "deposit" ? true : q.deposit_paid,
              balance_paid: stage === "balance" ? true : q.balance_paid,
            }
          : q
      );
      setStatus("idle");
    } catch (e) {
      setStatus("error");
      setErrorMsg(e instanceof Error ? e.message : "Something went wrong.");
    }
  }

  if (quote === "not_found") {
    return (
      <>
        <Nav />
        <div className="max-w-[640px] mx-auto px-8 py-32 text-center">
          <p className="font-display text-2xl mb-3">Quote not found.</p>
          <p className="text-stone text-sm">
            This link may have expired or been mistyped — reach out to
            hello@studionovelle.com and we&rsquo;ll send a new one.
          </p>
        </div>
        <Footer />
      </>
    );
  }

  const stage: "deposit" | "balance" | "done" | null =
    quote === null ? null : !quote.deposit_paid ? "deposit" : !quote.balance_paid ? "balance" : "done";

  const stageAmount =
    quote === null || quote === "not_found"
      ? 0
      : stage === "deposit"
      ? quote.deposit_naira
      : quote.balance_naira;

  return (
    <>
      <Nav />

      <div className="max-w-[640px] mx-auto px-8 py-28">
        <Reveal>
          {quote === null ? (
            <p className="text-stone text-sm">Loading your quote…</p>
          ) : (
            <>
              <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-7">
                Project Quote
              </span>
              <h1 className="font-display font-light text-[32px] md:text-[48px] leading-[1.1] tracking-tight mb-8">
                {quote.service_title}
              </h1>

              <div className="border-t border-line py-6 space-y-3 mb-4">
                <div className="flex justify-between text-sm">
                  <span className="text-stone">Total project cost</span>
                  <span className="font-display text-lg">₦{quote.total_naira.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-stone">Deposit (50%, due to begin)</span>
                  <span className={quote.deposit_paid ? "text-olive" : ""}>
                    ₦{quote.deposit_naira.toLocaleString()} {quote.deposit_paid && "✓ Paid"}
                  </span>
                </div>
                <div className="flex justify-between text-sm border-b border-line pb-6">
                  <span className="text-stone">Balance (due before delivery)</span>
                  <span className={quote.balance_paid ? "text-olive" : ""}>
                    ₦{quote.balance_naira.toLocaleString()} {quote.balance_paid && "✓ Paid"}
                  </span>
                </div>
              </div>

              {stage === "done" ? (
                <div className="border border-line bg-beige p-10">
                  <span className="font-mono text-[10px] uppercase tracking-wider text-olive block mb-4">
                    Fully Paid
                  </span>
                  <h3 className="font-display text-2xl mb-3">All settled.</h3>
                  <p className="text-stone text-sm leading-relaxed">
                    Thank you — this project is paid in full. We&rsquo;ll be in
                    touch with final delivery details.
                  </p>
                </div>
              ) : (
                <div>
                  <p className="text-stone text-sm mb-6">
                    {stage === "deposit"
                      ? "Pay your deposit below to begin the project."
                      : "Your deposit is in — pay the remaining balance before final delivery."}
                  </p>

                  <div className="mb-6">
                    <label className="block font-mono text-[10px] uppercase tracking-wider text-stone mb-3">
                      Your Name
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Full name"
                      className="w-full border-0 border-b border-line bg-transparent py-3 text-[17px] focus:outline-none focus:border-gold transition-colors placeholder:text-stone/50"
                    />
                  </div>
                  <div className="mb-8">
                    <label className="block font-mono text-[10px] uppercase tracking-wider text-stone mb-3">
                      Email
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@company.com"
                      className="w-full border-0 border-b border-line bg-transparent py-3 text-[17px] focus:outline-none focus:border-gold transition-colors placeholder:text-stone/50"
                    />
                  </div>

                  {status === "verifying" && (
                    <p className="mb-4 text-xs text-stone">Confirming your payment…</p>
                  )}
                  {status === "error" && (
                    <p className="mb-4 text-xs text-red-700">{errorMsg}</p>
                  )}

                  <div className="flex flex-wrap gap-4">
                    <PaystackButton
                      email={email}
                      amountNaira={stageAmount}
                      metadata={{ quote_id: quote.id, stage }}
                      onSuccess={(reference) => pay(stage!, "paystack", reference)}
                    />
                    <FlutterwaveButton
                      email={email}
                      name={name}
                      amountNaira={stageAmount}
                      description={quote.service_title}
                      metadata={{ quote_id: quote.id, stage }}
                      onSuccess={(transactionId) => pay(stage!, "flutterwave", transactionId)}
                    />
                  </div>
                </div>
              )}
            </>
          )}
        </Reveal>
      </div>

      <Footer />
    </>
  );
}
