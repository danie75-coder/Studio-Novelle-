"use client";

import { useState } from "react";
import { notFound } from "next/navigation";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import PaystackButton from "@/components/PaystackButton";
import FlutterwaveButton from "@/components/FlutterwaveButton";
import { getService } from "@/lib/services";

export default function Checkout({ params }: { params: { slug: string } }) {
  const service = getService(params.slug);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "verifying" | "success" | "error">("idle");

  if (!service || !service.fixedPrice || service.priceNaira === null) {
    notFound();
  }

  async function handlePaystackSuccess(reference: string) {
    setStatus("verifying");
    try {
      const res = await fetch("/api/paystack/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reference }),
      });
      if (!res.ok) throw new Error("verify failed");
      setStatus("success");
    } catch {
      setStatus("error");
    }
  }

  async function handleFlutterwaveSuccess(transactionId: string) {
    setStatus("verifying");
    try {
      const res = await fetch("/api/flutterwave/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          transactionId,
          expectedAmountNaira: service!.priceNaira,
        }),
      });
      if (!res.ok) throw new Error("verify failed");
      setStatus("success");
    } catch {
      setStatus("error");
    }
  }

  return (
    <>
      <Nav />

      <div className="max-w-[640px] mx-auto px-8 py-28">
        <Reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-7">
            Checkout — File {service!.num}
          </span>
          <h1 className="font-display font-light text-[36px] md:text-[52px] leading-[1.1] tracking-tight mb-4">
            {service!.title}
          </h1>
          <p className="text-stone text-base leading-relaxed mb-10">
            {service!.description}
          </p>

          <div className="flex justify-between items-baseline border-t border-b border-line py-6 mb-10">
            <span className="font-mono text-[11px] uppercase tracking-wider text-stone">
              Total due today
            </span>
            <span className="font-display text-3xl">{service!.priceLabel}</span>
          </div>

          {status === "success" ? (
            <div className="border border-line bg-beige p-10">
              <span className="font-mono text-[10px] uppercase tracking-wider text-olive block mb-4">
                Payment Confirmed
              </span>
              <h3 className="font-display text-2xl mb-3">You&rsquo;re booked in.</h3>
              <p className="text-stone text-sm leading-relaxed">
                We&rsquo;ll email you at {email} within one business day with
                your creative brief questionnaire and next steps.
              </p>
            </div>
          ) : (
            <div>
              <div className="mb-6">
                <label className="block font-mono text-[10px] uppercase tracking-wider text-stone mb-3">
                  Your Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Full name"
                  className="w-full border-0 border-b border-line bg-transparent py-3 text-[17px] focus:outline-none focus:border-gold transition-colors placeholder:text-stone/50"
                />
              </div>
              <div className="mb-8">
                <label className="block font-mono text-[10px] uppercase tracking-wider text-stone mb-3">
                  Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@company.com"
                  className="w-full border-0 border-b border-line bg-transparent py-3 text-[17px] focus:outline-none focus:border-gold transition-colors placeholder:text-stone/50"
                />
              </div>

              {status === "verifying" && (
                <p className="mb-4 text-xs text-stone">Confirming your payment…</p>
              )}
              {status === "error" && (
                <p className="mb-4 text-xs text-red-700">
                  Payment went through but we couldn&rsquo;t confirm it automatically —
                  email hello@studionovelle.com with your reference and we&rsquo;ll sort it out.
                </p>
              )}

              <div className="flex flex-wrap gap-4">
                <PaystackButton
                  email={email}
                  amountNaira={service!.priceNaira!}
                  metadata={{ service: service!.title, slug: service!.slug, name }}
                  onSuccess={handlePaystackSuccess}
                />
                <FlutterwaveButton
                  email={email}
                  name={name}
                  amountNaira={service!.priceNaira!}
                  description={service!.title}
                  metadata={{ service: service!.title, slug: service!.slug }}
                  onSuccess={handleFlutterwaveSuccess}
                />
              </div>

              <p className="mt-5 text-xs text-stone leading-relaxed">
                Both options accept Nigerian and international cards. This
                service is paid in full upfront.
              </p>
            </div>
          )}
        </Reveal>
      </div>

      <Footer />
    </>
  );
}
