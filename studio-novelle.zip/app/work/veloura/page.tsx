import type { Metadata } from "next";
import CaseStudy from "@/components/CaseStudy";
import { getProject } from "@/lib/projects";

export const metadata: Metadata = {
  title: "Studio Novelle — Veloura Parfum",
  description: "Case File 002 — Veloura Parfum. A luxury fragrance identity built to create desire before the first spray.",
};

export default function Page() {
  return <CaseStudy project={getProject("veloura")!} />;
}
