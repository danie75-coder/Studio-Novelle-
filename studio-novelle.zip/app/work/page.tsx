import type { Metadata } from "next";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import ProjectCard from "@/components/ProjectCard";
import { projects } from "@/lib/projects";

export const metadata: Metadata = {
  title: "Studio Novelle — Selected Work",
  description: "A growing archive of brand worlds built by Studio Novelle.",
};

export default function Work() {
  return (
    <>
      <Nav active="/work" />

      <header className="max-w-[1180px] mx-auto px-8 pt-32 md:pt-36 pb-20">
        <Reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
            Selected Work
          </span>
        </Reveal>
        <Reveal delay={0.1}>
          <h1 className="font-display font-light text-[38px] md:text-[76px] leading-[1.05] tracking-tight max-w-[820px]">
            A growing archive of brand worlds.
          </h1>
        </Reveal>
      </header>

      <section className="max-w-[1180px] mx-auto px-8 pb-28">
        <Reveal>
          <div className="grid md:grid-cols-3 gap-px bg-line border border-line">
            {projects.map((p) => (
              <ProjectCard
                key={p.slug}
                href={`/work/${p.slug}`}
                fileNo={`File ${p.fileNo}`}
                name={p.name}
                industry={p.industry}
                gradient={p.gradient}
              />
            ))}
          </div>
        </Reveal>
      </section>

      <Footer quote="Perception creates value." />
    </>
  );
}
