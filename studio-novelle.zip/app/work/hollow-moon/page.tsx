import type { Metadata } from "next";
import CaseStudy from "@/components/CaseStudy";
import { getProject } from "@/lib/projects";

export const metadata: Metadata = {
  title: "Studio Novelle — Hollow Moon",
  description: "Case File 001 — Hollow Moon. A skincare identity built around ritual, not routine.",
};

export default function Page() {
  return <CaseStudy project={getProject("hollow-moon")!} />;
}
