import type { Metadata } from "next";
import CaseStudy from "@/components/CaseStudy";
import { getProject } from "@/lib/projects";

export const metadata: Metadata = {
  title: "Studio Novelle — Aurelia Hotels",
  description: "Case File 003 — Aurelia Hotels. A hospitality identity built for quiet confidence.",
};

export default function Page() {
  return <CaseStudy project={getProject("aurelia-hotels")!} />;
}
