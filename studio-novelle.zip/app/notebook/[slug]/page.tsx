import { notFound } from "next/navigation";
import Link from "next/link";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import { getNote, notes } from "@/lib/notebook";

export function generateStaticParams() {
  return notes.map((n) => ({ slug: n.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }) {
  const note = getNote(params.slug);
  return {
    title: note ? `Studio Novelle — ${note.title}` : "Studio Novelle — Studio Notebook",
    description: note?.excerpt,
  };
}

export default function NotebookEntry({ params }: { params: { slug: string } }) {
  const note = getNote(params.slug);
  if (!note) notFound();

  return (
    <>
      <Nav backLink={{ href: "/notebook", label: "← Studio Notebook" }} />

      <article className="max-w-[720px] mx-auto px-8 pt-32 md:pt-36 pb-28">
        <Reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
            Observation — {note.num}
          </span>
          <h1 className="font-display font-light text-[34px] md:text-[54px] leading-[1.12] tracking-tight mb-12">
            {note.title}
          </h1>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="space-y-7 border-t border-line pt-12">
            {note.body.map((p, i) => (
              <p key={i} className="text-lg leading-[1.8]">
                {p}
              </p>
            ))}
          </div>
        </Reveal>
      </article>

      <Footer quote="Silence is stronger than noise." />
    </>
  );
}
