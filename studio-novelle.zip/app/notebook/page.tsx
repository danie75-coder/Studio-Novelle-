import type { Metadata } from "next";
import Link from "next/link";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import { notes } from "@/lib/notebook";

export const metadata: Metadata = {
  title: "Studio Novelle — Studio Notebook",
  description: "Observations on typography, space, and material — from the Studio Novelle team.",
};

export default function Notebook() {
  return (
    <>
      <Nav active="/notebook" />

      <header className="max-w-[1180px] mx-auto px-8 pt-32 md:pt-36 pb-16">
        <Reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
            Studio Notebook
          </span>
        </Reveal>
        <Reveal delay={0.1}>
          <h1 className="font-display font-light text-[38px] md:text-[76px] leading-[1.05] tracking-tight max-w-[760px]">
            Observations, not articles.
          </h1>
        </Reveal>
      </header>

      <section className="max-w-[1180px] mx-auto px-8 pb-28 border-t border-line">
        {notes.map((n, i) => (
          <Reveal key={n.slug} delay={(i % 3) * 0.08}>
            <Link
              href={`/notebook/${n.slug}`}
              className="grid md:grid-cols-[80px_1fr] gap-6 md:gap-10 items-baseline py-10 border-b border-line group transition-all duration-400 ease-studio hover:pl-3"
            >
              <span className="font-mono text-xs text-gold tracking-wider">
                {n.num}
              </span>
              <div>
                <h2 className="font-display text-2xl md:text-[32px] tracking-tight mb-3 transition-colors duration-300 group-hover:text-gold">
                  {n.title}
                </h2>
                <p className="text-stone text-[15px] leading-relaxed max-w-[600px]">
                  {n.excerpt}
                </p>
              </div>
            </Link>
          </Reveal>
        ))}
      </section>

      <Footer quote="Every detail communicates." />
    </>
  );
}
