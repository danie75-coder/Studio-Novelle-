"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import { getSupabaseBrowser } from "@/lib/supabaseClient";

type Order = {
  id: string;
  reference: string;
  status: string;
  service_title: string;
  amount_naira: number;
  currency: string;
  created_at: string;
};

type Quote = {
  id: string;
  service_title: string;
  total_naira: number;
  deposit_naira: number;
  balance_naira: number;
  deposit_paid: boolean;
  balance_paid: boolean;
};

export default function Vault() {
  const [authState, setAuthState] = useState<"checking" | "signed-out" | "signed-in">("checking");
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [quotes, setQuotes] = useState<Quote[]>([]);

  useEffect(() => {
    const supabase = getSupabaseBrowser();
    if (!supabase) {
      setAuthState("signed-out");
      return;
    }

    supabase.auth.getSession().then(({ data }) => {
      if (data.session) {
        setUserEmail(data.session.user.email ?? null);
        setAuthState("signed-in");
      } else {
        setAuthState("signed-out");
      }
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session) {
        setUserEmail(session.user.email ?? null);
        setAuthState("signed-in");
      } else {
        setAuthState("signed-out");
      }
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (authState !== "signed-in") return;
    const supabase = getSupabaseBrowser();
    if (!supabase) return;

    supabase
      .from("orders")
      .select("id, reference, status, service_title, amount_naira, currency, created_at")
      .order("created_at", { ascending: false })
      .then(({ data }) => setOrders((data as Order[]) ?? []));

    supabase
      .from("quotes")
      .select("id, service_title, total_naira, deposit_naira, balance_naira, deposit_paid, balance_paid")
      .then(({ data }) => setQuotes((data as Quote[]) ?? []));
  }, [authState]);

  async function handleSignOut() {
    const supabase = getSupabaseBrowser();
    await supabase?.auth.signOut();
  }

  if (authState === "checking") {
    return (
      <>
        <Nav />
        <div className="max-w-[1180px] mx-auto px-8 py-32">
          <p className="text-stone text-sm">Loading your workspace…</p>
        </div>
        <Footer />
      </>
    );
  }

  if (authState === "signed-out") {
    return (
      <>
        <Nav />
        <div className="max-w-[640px] mx-auto px-8 py-32 text-center">
          <p className="font-display text-2xl mb-4">You&rsquo;re not signed in.</p>
          <Link
            href="/vault/login"
            className="inline-flex items-center gap-2.5 font-sans text-[13px] font-semibold uppercase tracking-wider px-8 py-4 rounded-sm bg-charcoal text-ivory transition-all duration-500 ease-studio hover:bg-gold hover:text-charcoal"
          >
            Go to Client Login
          </Link>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Nav />

      <div className="max-w-[1180px] mx-auto px-8 py-24">
        <Reveal>
          <div className="flex justify-between items-end flex-wrap gap-6 mb-16">
            <div>
              <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-6">
                The Studio Vault
              </span>
              <h1 className="font-display font-light text-[32px] md:text-[48px] tracking-tight">
                Welcome back.
              </h1>
              <p className="text-stone text-sm mt-2">{userEmail}</p>
            </div>
            <button
              onClick={handleSignOut}
              className="font-mono text-[11px] uppercase tracking-wider text-stone hover:text-charcoal transition-colors"
            >
              Sign Out
            </button>
          </div>
        </Reveal>

        {quotes.length > 0 && (
          <Reveal>
            <h2 className="font-display text-2xl mb-6">Active Quotes</h2>
            <div className="border border-line mb-16">
              {quotes.map((q) => (
                <div key={q.id} className="flex justify-between items-center flex-wrap gap-4 px-6 py-6 border-b border-line last:border-b-0">
                  <div>
                    <h3 className="font-display text-lg">{q.service_title}</h3>
                    <p className="font-mono text-[11px] text-stone uppercase tracking-wider mt-1">
                      Total ₦{q.total_naira.toLocaleString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-6">
                    <span className="font-mono text-[11px] uppercase tracking-wider">
                      Deposit {q.deposit_paid ? "✓" : "—"} · Balance {q.balance_paid ? "✓" : "—"}
                    </span>
                    {!(q.deposit_paid && q.balance_paid) && (
                      <Link
                        href={`/checkout/quote/${q.id}`}
                        className="font-mono text-[11px] uppercase tracking-wider border-b border-charcoal hover:text-gold hover:border-gold transition-colors"
                      >
                        Pay →
                      </Link>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Reveal>
        )}

        <Reveal>
          <h2 className="font-display text-2xl mb-6">Order History</h2>
          {orders.length === 0 ? (
            <p className="text-stone text-sm">
              No orders yet — anything booked through Services or a quote
              will show up here.
            </p>
          ) : (
            <div className="border border-line">
              {orders.map((o) => (
                <div key={o.id} className="flex justify-between items-center flex-wrap gap-4 px-6 py-6 border-b border-line last:border-b-0">
                  <div>
                    <h3 className="font-display text-lg">{o.service_title}</h3>
                    <p className="font-mono text-[11px] text-stone uppercase tracking-wider mt-1">
                      {new Date(o.created_at).toLocaleDateString()} · Ref {o.reference}
                    </p>
                  </div>
                  <div className="flex items-center gap-6">
                    <span className="font-mono text-[11px] uppercase tracking-wider text-olive">
                      {o.status.replace("_", " ")}
                    </span>
                    <span className="font-display text-lg">
                      ₦{o.amount_naira.toLocaleString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Reveal>
      </div>

      <Footer />
    </>
  );
}
