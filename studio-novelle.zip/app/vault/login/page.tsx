"use client";

import { useState } from "react";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import { getSupabaseBrowser } from "@/lib/supabaseClient";

export default function VaultLogin() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const supabase = getSupabaseBrowser();
    if (!supabase) {
      setStatus("error");
      return;
    }

    setStatus("sending");
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo:
          typeof window !== "undefined" ? `${window.location.origin}/vault` : undefined,
      },
    });
    setStatus(error ? "error" : "sent");
  }

  return (
    <>
      <Nav />

      <div className="max-w-[480px] mx-auto px-8 py-32">
        <Reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-7">
            The Studio Vault
          </span>
          <h1 className="font-display font-light text-[34px] md:text-[48px] leading-[1.1] tracking-tight mb-6">
            Client login.
          </h1>

          {status === "sent" ? (
            <div className="border border-line bg-beige p-8">
              <p className="text-sm leading-relaxed">
                Check <strong>{email}</strong> for a sign-in link. It expires
                shortly, so use it soon after it arrives.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <p className="text-stone text-sm leading-relaxed mb-8">
                Enter the email you used when booking your project. We&rsquo;ll
                send a one-time link — no password needed.
              </p>
              <div className="mb-6">
                <label className="block font-mono text-[10px] uppercase tracking-wider text-stone mb-3">
                  Email
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@company.com"
                  className="w-full border-0 border-b border-line bg-transparent py-3 text-[17px] focus:outline-none focus:border-gold transition-colors placeholder:text-stone/50"
                />
              </div>
              <button
                type="submit"
                disabled={status === "sending"}
                className="inline-flex items-center gap-2.5 font-sans text-[13px] font-semibold uppercase tracking-wider px-8 py-4 rounded-sm bg-charcoal text-ivory transition-all duration-500 ease-studio hover:bg-gold hover:text-charcoal hover:-translate-y-0.5 disabled:opacity-50 disabled:pointer-events-none"
              >
                {status === "sending" ? "Sending…" : "Send Sign-In Link"}
              </button>
              {status === "error" && (
                <p className="mt-4 text-xs text-red-700">
                  Something went wrong sending your link — please try again.
                </p>
              )}
            </form>
          )}
        </Reveal>
      </div>

      <Footer />
    </>
  );
}
