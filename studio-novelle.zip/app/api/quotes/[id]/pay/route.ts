import { NextRequest, NextResponse } from "next/server";
import { getQuote } from "@/lib/quotes";
import { recordQuoteStagePayment } from "@/lib/quotePayments";

type Body = {
  processor: "paystack" | "flutterwave";
  stage: "deposit" | "balance";
  reference?: string; // paystack
  transactionId?: string; // flutterwave
  clientEmail: string;
  clientName: string;
};

async function verifyPaystack(reference: string) {
  const secretKey = process.env.PAYSTACK_SECRET_KEY;
  if (!secretKey) throw new Error("PAYSTACK_SECRET_KEY not configured.");

  const res = await fetch(
    `https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,
    { headers: { Authorization: `Bearer ${secretKey}` } }
  );
  const json = await res.json();
  if (!res.ok || json?.data?.status !== "success") return null;
  return { amountNaira: (json.data.amount ?? 0) / 100, reference };
}

async function verifyFlutterwave(transactionId: string) {
  const secretKey = process.env.FLUTTERWAVE_SECRET_KEY;
  if (!secretKey) throw new Error("FLUTTERWAVE_SECRET_KEY not configured.");

  const res = await fetch(
    `https://api.flutterwave.com/v3/transactions/${encodeURIComponent(transactionId)}/verify`,
    { headers: { Authorization: `Bearer ${secretKey}` } }
  );
  const json = await res.json();
  const data = json?.data;
  if (!res.ok || data?.status !== "successful") return null;
  return { amountNaira: data.amount, reference: data.tx_ref };
}

// Client-triggered check, called right after the payment popup
// closes. Paystack/Flutterwave webhooks are the source of truth for
// this quote too — see app/api/paystack/webhook and
// app/api/flutterwave/webhook, which detect metadata.quote_id and
// call the same lib/quotePayments.ts logic independently.
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body: Body = await req.json();
    const { processor, stage, reference, transactionId, clientEmail, clientName } = body;

    const quote = await getQuote(params.id);
    if (!quote) {
      return NextResponse.json({ error: "Quote not found." }, { status: 404 });
    }

    if (stage === "deposit" && quote.deposit_paid) {
      return NextResponse.json({ ok: true, alreadyRecorded: true });
    }
    if (stage === "balance" && !quote.deposit_paid) {
      return NextResponse.json({ error: "Deposit must be paid first." }, { status: 400 });
    }
    if (stage === "balance" && quote.balance_paid) {
      return NextResponse.json({ ok: true, alreadyRecorded: true });
    }

    const expectedNaira = stage === "deposit" ? quote.deposit_naira : quote.balance_naira;

    let verified: { amountNaira: number; reference: string } | null = null;
    if (processor === "paystack" && reference) {
      verified = await verifyPaystack(reference);
    } else if (processor === "flutterwave" && transactionId) {
      verified = await verifyFlutterwave(transactionId);
    }

    if (!verified || verified.amountNaira < expectedNaira) {
      return NextResponse.json(
        { error: "Payment could not be verified." },
        { status: 400 }
      );
    }

    const result = await recordQuoteStagePayment({
      quoteId: params.id,
      stage,
      reference: verified.reference,
      amountNaira: verified.amountNaira,
      clientEmail,
      clientName,
    });

    return NextResponse.json({ ok: true, quote: result.quote });
  } catch (err) {
    console.error("Quote payment error:", err);
    return NextResponse.json(
      { error: "Something went wrong processing payment." },
      { status: 500 }
    );
  }
}
