import { NextRequest, NextResponse } from "next/server";
import { getQuote } from "@/lib/quotes";

// Public read — powers /checkout/quote/[id]. Intentionally omits
// client_email/client_name from the response; the checkout page asks
// the visitor to re-enter their email rather than trusting the URL.
export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const quote = await getQuote(params.id);

  if (!quote) {
    return NextResponse.json({ error: "Quote not found." }, { status: 404 });
  }

  return NextResponse.json({
    id: quote.id,
    service_title: quote.service_title,
    total_naira: quote.total_naira,
    deposit_naira: quote.deposit_naira,
    balance_naira: quote.balance_naira,
    deposit_paid: quote.deposit_paid,
    balance_paid: quote.balance_paid,
  });
}
