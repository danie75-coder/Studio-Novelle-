import { NextRequest, NextResponse } from "next/server";
import { createQuote } from "@/lib/quotes";
import { sendQuoteLinkToClient } from "@/lib/email";
import { requireAdmin } from "@/lib/adminAuth";

// Admin-only: creates a quote and emails the client their checkout
// link. Requires a valid Supabase session belonging to an email in
// ADMIN_EMAILS — see lib/adminAuth.ts. Called from /admin/quotes,
// which attaches the signed-in admin's access token as a Bearer
// header automatically.
export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req);
  if (!admin) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { clientName, clientEmail, serviceTitle, serviceSlug, totalNaira } =
      await req.json();

    if (!clientEmail || !serviceTitle || !totalNaira) {
      return NextResponse.json(
        { error: "clientEmail, serviceTitle, and totalNaira are required." },
        { status: 400 }
      );
    }

    const quote = await createQuote({
      clientName,
      clientEmail,
      serviceTitle,
      serviceSlug,
      totalNaira,
    });

    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
    const checkoutUrl = `${siteUrl}/checkout/quote/${quote.id}`;

    try {
      await sendQuoteLinkToClient({
        toEmail: clientEmail,
        clientName,
        serviceTitle,
        totalNaira: quote.total_naira,
        depositNaira: quote.deposit_naira,
        checkoutUrl,
      });
    } catch (e) {
      console.error("Failed to email quote link to client:", e);
    }

    return NextResponse.json({ ok: true, quote, checkoutUrl });
  } catch (err) {
    console.error("Failed to create quote:", err);
    return NextResponse.json(
      { error: "Something went wrong creating the quote." },
      { status: 500 }
    );
  }
}
