import { NextRequest, NextResponse } from "next/server";
import { recordPaidOrder } from "@/lib/orders";
import { recordQuoteStagePayment } from "@/lib/quotePayments";

// Flutterwave webhooks — configure this URL
// (https://yourdomain.com/api/flutterwave/webhook) in your
// Flutterwave dashboard under Settings → Webhooks, along with a
// "Secret Hash" value that must match FLUTTERWAVE_SECRET_HASH below.
// Unlike Paystack, Flutterwave doesn't sign the payload — it just
// echoes the secret hash back in a header for you to compare.
export async function POST(req: NextRequest) {
  const expectedHash = process.env.FLUTTERWAVE_SECRET_HASH;
  if (!expectedHash) {
    console.error("Missing FLUTTERWAVE_SECRET_HASH — cannot verify webhook");
    return NextResponse.json({ error: "Not configured" }, { status: 500 });
  }

  const signature = req.headers.get("verif-hash");
  if (!signature || signature !== expectedHash) {
    console.warn("Invalid Flutterwave webhook signature — rejecting");
    return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  }

  let event: { event?: string; data?: Record<string, any> };
  try {
    event = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }

  const data = event.data;

  if (
    (event.event === "charge.completed" || event.event === "charge.success") &&
    data?.status === "successful"
  ) {
    const quoteId = data.meta?.quote_id;

    try {
      if (quoteId) {
        // Deposit or balance payment on a custom-scope quote — route
        // to the quote-specific recorder, not the fixed-price one.
        await recordQuoteStagePayment({
          quoteId,
          stage: data.meta?.stage === "balance" ? "balance" : "deposit",
          reference: data.tx_ref,
          amountNaira: data.amount,
          clientEmail: data.customer?.email ?? "",
          clientName: data.meta?.name ?? "",
        });
      } else {
        await recordPaidOrder({
          reference: data.tx_ref,
          amountNaira: data.amount,
          currency: data.currency ?? "NGN",
          customerEmail: data.customer?.email ?? "",
          customerName: data.meta?.name ?? "",
          serviceTitle: data.meta?.service ?? "Studio Novelle Service",
          serviceSlug: data.meta?.slug ?? "",
          metadata: data.meta ?? {},
        });
      }
    } catch (e) {
      console.error("Failed to record payment from Flutterwave webhook:", e);
    }
  }

  return NextResponse.json({ received: true });
}
