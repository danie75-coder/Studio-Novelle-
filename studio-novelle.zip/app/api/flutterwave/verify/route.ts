import { NextRequest, NextResponse } from "next/server";
import { recordPaidOrder } from "@/lib/orders";

// Client-triggered check, called right after the Flutterwave modal
// closes. The webhook at /api/flutterwave/webhook is the real source
// of truth — this is a fast path for instant UI feedback.
export async function POST(req: NextRequest) {
  try {
    const { transactionId, expectedAmountNaira } = await req.json();

    if (!transactionId) {
      return NextResponse.json({ error: "Missing transaction id." }, { status: 400 });
    }

    const secretKey = process.env.FLUTTERWAVE_SECRET_KEY;
    if (!secretKey) {
      console.error("Missing FLUTTERWAVE_SECRET_KEY env var");
      return NextResponse.json(
        { error: "Payments are not configured yet." },
        { status: 500 }
      );
    }

    const verifyRes = await fetch(
      `https://api.flutterwave.com/v3/transactions/${encodeURIComponent(transactionId)}/verify`,
      { headers: { Authorization: `Bearer ${secretKey}` } }
    );
    const verifyJson = await verifyRes.json();
    const data = verifyJson?.data;

    // Flutterwave's docs recommend re-checking status, currency, and
    // amount server-side rather than trusting the client callback.
    const isValid =
      verifyRes.ok &&
      data?.status === "successful" &&
      data?.currency === "NGN" &&
      Number(data?.amount) >= Number(expectedAmountNaira ?? 0);

    if (!isValid) {
      return NextResponse.json(
        { error: "Payment could not be verified.", details: verifyJson },
        { status: 400 }
      );
    }

    await recordPaidOrder({
      reference: data.tx_ref,
      amountNaira: data.amount,
      currency: data.currency,
      customerEmail: data.customer?.email ?? "",
      customerName: data.meta?.name ?? "",
      serviceTitle: data.meta?.service ?? "Studio Novelle Service",
      serviceSlug: data.meta?.slug ?? "",
      metadata: data.meta ?? {},
    });

    return NextResponse.json({ ok: true, data });
  } catch (err) {
    console.error("Flutterwave verify error:", err);
    return NextResponse.json(
      { error: "Something went wrong verifying payment." },
      { status: 500 }
    );
  }
}
