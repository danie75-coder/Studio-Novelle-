import { NextRequest, NextResponse } from "next/server";
import { recordPaidOrder } from "@/lib/orders";

// Client-triggered check, called right after the Paystack popup
// closes — gives the checkout page instant feedback. The webhook at
// /api/paystack/webhook is the real source of truth for anything
// that happens after the client's browser closes; this route is a
// fast path, not a replacement for it.
export async function POST(req: NextRequest) {
  try {
    const { reference } = await req.json();

    if (!reference) {
      return NextResponse.json({ error: "Missing reference." }, { status: 400 });
    }

    const secretKey = process.env.PAYSTACK_SECRET_KEY;
    if (!secretKey) {
      console.error("Missing PAYSTACK_SECRET_KEY env var");
      return NextResponse.json(
        { error: "Payments are not configured yet." },
        { status: 500 }
      );
    }

    const verifyRes = await fetch(
      `https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,
      { headers: { Authorization: `Bearer ${secretKey}` } }
    );
    const verifyJson = await verifyRes.json();

    if (!verifyRes.ok || verifyJson?.data?.status !== "success") {
      return NextResponse.json(
        { error: "Payment could not be verified.", details: verifyJson },
        { status: 400 }
      );
    }

    const data = verifyJson.data;
    await recordPaidOrder({
      reference,
      amountNaira: (data.amount ?? 0) / 100,
      currency: data.currency ?? "NGN",
      customerEmail: data.customer?.email ?? "",
      customerName: data.metadata?.name ?? "",
      serviceTitle: data.metadata?.service ?? "Studio Novelle Service",
      serviceSlug: data.metadata?.slug ?? "",
      metadata: data.metadata ?? {},
    });

    return NextResponse.json({ ok: true, data });
  } catch (err) {
    console.error("Paystack verify error:", err);
    return NextResponse.json(
      { error: "Something went wrong verifying payment." },
      { status: 500 }
    );
  }
}
