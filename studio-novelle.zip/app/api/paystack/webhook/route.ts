import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { recordPaidOrder } from "@/lib/orders";
import { recordQuoteStagePayment } from "@/lib/quotePayments";

// Paystack webhooks — the source of truth for a payment, independent
// of whether the client's browser stayed open. Configure this URL
// (https://yourdomain.com/api/paystack/webhook) in your Paystack
// dashboard under Settings → API Keys & Webhooks.
export async function POST(req: NextRequest) {
  const secretKey = process.env.PAYSTACK_SECRET_KEY;
  if (!secretKey) {
    console.error("Missing PAYSTACK_SECRET_KEY — cannot verify webhook signature");
    return NextResponse.json({ error: "Not configured" }, { status: 500 });
  }

  // Signature is computed over the raw body — must read as text
  // before any JSON parsing.
  const rawBody = await req.text();
  const signature = req.headers.get("x-paystack-signature");

  const expected = crypto
    .createHmac("sha512", secretKey)
    .update(rawBody)
    .digest("hex");

  if (!signature || signature !== expected) {
    console.warn("Invalid Paystack webhook signature — rejecting");
    return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  }

  let event: { event?: string; data?: Record<string, any> };
  try {
    event = JSON.parse(rawBody);
  } catch {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }

  if (event.event === "charge.success" && event.data) {
    const data = event.data;
    const quoteId = data.metadata?.quote_id;

    try {
      if (quoteId) {
        // Deposit or balance payment on a custom-scope quote — route
        // to the quote-specific recorder, not the fixed-price one.
        await recordQuoteStagePayment({
          quoteId,
          stage: data.metadata?.stage === "balance" ? "balance" : "deposit",
          reference: data.reference,
          amountNaira: (data.amount ?? 0) / 100,
          clientEmail: data.customer?.email ?? "",
          clientName: data.metadata?.name ?? "",
        });
      } else {
        await recordPaidOrder({
          reference: data.reference,
          amountNaira: (data.amount ?? 0) / 100,
          currency: data.currency ?? "NGN",
          customerEmail: data.customer?.email ?? "",
          customerName: data.metadata?.name ?? "",
          serviceTitle: data.metadata?.service ?? "Studio Novelle Service",
          serviceSlug: data.metadata?.slug ?? "",
          metadata: data.metadata ?? {},
        });
      }
    } catch (e) {
      console.error("Failed to record payment from webhook:", e);
      // Still acknowledge receipt — Paystack retries on non-2xx, and
      // the client-triggered call is a fallback for the common case
      // anyway.
    }
  }

  return NextResponse.json({ received: true });
}
