import type { Metadata } from "next";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import Button from "@/components/Button";
import MenuRow from "@/components/MenuRow";
import { services } from "@/lib/services";

export const metadata: Metadata = {
  title: "Studio Novelle — Services",
  description: "Brand identity, creative direction, and marketing design — starting rates.",
};

export default function Services() {
  return (
    <>
      <Nav active="/services" />

      <header className="max-w-[1180px] mx-auto px-8 pt-32 md:pt-36 pb-16">
        <Reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
            Services
          </span>
        </Reveal>
        <Reveal delay={0.1}>
          <h1 className="font-display font-light text-[40px] md:text-[84px] leading-[1.05] tracking-tight max-w-[760px] mb-7">
            Every service, one <em className="italic text-gold font-normal">standard.</em>
          </h1>
        </Reveal>
        <Reveal delay={0.22}>
          <p className="text-stone text-base max-w-[460px] leading-relaxed">
            Fixed-price work for quick turnarounds. Custom scopes for full
            brand builds. Every project starts with the same question — what
            should people feel?
          </p>
        </Reveal>
      </header>

      <section className="max-w-[1180px] mx-auto px-8 pb-24 border-t border-line">
        {services.map((s, i) => (
          <Reveal key={s.slug} delay={(i % 4) * 0.06}>
            <MenuRow
              num={s.num}
              title={s.title}
              description={s.description}
              priceLabel={s.priceLabel}
              actionHref={s.fixedPrice ? `/checkout/${s.slug}` : "/contact"}
              actionLabel={s.fixedPrice ? "Pay Now →" : "Request a Quote →"}
            />
          </Reveal>
        ))}
      </section>

      <Reveal>
        <section className="py-28 bg-beige border-t border-b border-line">
          <div className="max-w-[1180px] mx-auto px-8 grid md:grid-cols-[200px_1fr] gap-14">
            <span className="font-mono text-xs uppercase tracking-widest text-gold">
              How It Works
            </span>
            <div>
              <div className="flex flex-wrap items-center font-display text-lg md:text-2xl tracking-tight">
                {["Choose a service", "Book a date", "Pay a deposit", "We design", "You approve"].map((step, i) => (
                  <span key={step} className="flex items-center">
                    <span className="py-2">{step}</span>
                    {i < 4 && <span className="text-gold px-4 font-sans text-base">→</span>}
                  </span>
                ))}
              </div>
              <p className="mt-7 text-stone text-sm max-w-[520px] leading-relaxed">
                Fixed-price services are paid in full upfront. Larger
                branding projects run on a 50% deposit before work begins,
                50% before final delivery.
              </p>
            </div>
          </div>
        </section>
      </Reveal>

      <section className="max-w-[1180px] mx-auto px-8 py-32 md:py-36 text-center">
        <Reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
            Not Sure Which Service Fits?
          </span>
        </Reveal>
        <Reveal delay={0.1}>
          <h2 className="font-display font-light text-[38px] md:text-[72px] leading-tight tracking-tight mb-11">
            Let&rsquo;s find the right
            <br />
            <em className="italic text-gold">starting point.</em>
          </h2>
        </Reveal>
        <Reveal delay={0.22}>
          <div className="flex justify-center">
            <Button href="/book" variant="primary">Book a Project</Button>
          </div>
        </Reveal>
      </section>

      <Footer quote="Every detail communicates." />
    </>
  );
}
