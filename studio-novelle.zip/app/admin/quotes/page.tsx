"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Reveal from "@/components/Reveal";
import { getSupabaseBrowser } from "@/lib/supabaseClient";

type Quote = {
  id: string;
  client_name: string | null;
  client_email: string;
  service_title: string;
  total_naira: number;
  deposit_naira: number;
  balance_naira: number;
  deposit_paid: boolean;
  balance_paid: boolean;
  created_at: string;
};

export default function AdminQuotes() {
  const [authState, setAuthState] = useState<"checking" | "signed-out" | "signed-in">("checking");
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [token, setToken] = useState<string | null>(null);

  const [quotes, setQuotes] = useState<Quote[] | null>(null);
  const [listError, setListError] = useState("");

  const [clientName, setClientName] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [serviceTitle, setServiceTitle] = useState("");
  const [totalNaira, setTotalNaira] = useState("");
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState("");
  const [lastCheckoutUrl, setLastCheckoutUrl] = useState("");

  useEffect(() => {
    const supabase = getSupabaseBrowser();
    if (!supabase) {
      setAuthState("signed-out");
      return;
    }

    supabase.auth.getSession().then(({ data }) => {
      if (data.session) {
        setUserEmail(data.session.user.email ?? null);
        setToken(data.session.access_token);
        setAuthState("signed-in");
      } else {
        setAuthState("signed-out");
      }
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session) {
        setUserEmail(session.user.email ?? null);
        setToken(session.access_token);
        setAuthState("signed-in");
      } else {
        setAuthState("signed-out");
        setToken(null);
      }
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  async function loadQuotes(authToken: string) {
    setListError("");
    const res = await fetch("/api/quotes", {
      headers: { Authorization: `Bearer ${authToken}` },
    });
    if (!res.ok) {
      setListError(
        res.status === 401
          ? "This account isn't authorized as studio admin. Check ADMIN_EMAILS."
          : "Failed to load quotes."
      );
      return;
    }
    const json = await res.json();
    setQuotes(json.quotes);
  }

  useEffect(() => {
    if (token) loadQuotes(token);
  }, [token]);

  async function handleSignOut() {
    const supabase = getSupabaseBrowser();
    await supabase?.auth.signOut();
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!token) return;

    setCreating(true);
    setCreateError("");
    setLastCheckoutUrl("");

    try {
      const res = await fetch("/api/quotes/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          clientName,
          clientEmail,
          serviceTitle,
          totalNaira: Number(totalNaira),
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to create quote.");

      setLastCheckoutUrl(json.checkoutUrl);
      setClientName("");
      setClientEmail("");
      setServiceTitle("");
      setTotalNaira("");
      loadQuotes(token);
    } catch (err) {
      setCreateError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setCreating(false);
    }
  }

  if (authState === "checking") {
    return (
      <>
        <Nav />
        <div className="max-w-[1180px] mx-auto px-8 py-32">
          <p className="text-stone text-sm">Checking your session…</p>
        </div>
        <Footer />
      </>
    );
  }

  if (authState === "signed-out") {
    return (
      <>
        <Nav />
        <div className="max-w-[640px] mx-auto px-8 py-32 text-center">
          <p className="font-display text-2xl mb-4">Admin sign-in required.</p>
          <Link
            href="/admin/login"
            className="inline-flex items-center gap-2.5 font-sans text-[13px] font-semibold uppercase tracking-wider px-8 py-4 rounded-sm bg-charcoal text-ivory transition-all duration-500 ease-studio hover:bg-gold hover:text-charcoal"
          >
            Go to Admin Login
          </Link>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Nav />
      <div className="max-w-[1180px] mx-auto px-8 py-24">
        <Reveal>
          <div className="flex justify-between items-end flex-wrap gap-6 mb-14">
            <div>
              <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-7">
                Studio Admin
              </span>
              <h1 className="font-display font-light text-[32px] md:text-[44px] tracking-tight">
                Create a quote.
              </h1>
              <p className="text-stone text-sm mt-2">{userEmail}</p>
            </div>
            <button
              onClick={handleSignOut}
              className="font-mono text-[11px] uppercase tracking-wider text-stone hover:text-charcoal transition-colors"
            >
              Sign Out
            </button>
          </div>

          {listError && (
            <p className="mb-8 text-sm text-red-700 border border-red-200 bg-red-50 px-5 py-4">
              {listError}
            </p>
          )}

          <form onSubmit={handleCreate} className="grid md:grid-cols-2 gap-8 mb-8">
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-stone mb-3">Client Name</label>
              <input required value={clientName} onChange={(e) => setClientName(e.target.value)} className="w-full border-0 border-b border-line bg-transparent py-3 text-[16px] focus:outline-none focus:border-gold" />
            </div>
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-stone mb-3">Client Email</label>
              <input required type="email" value={clientEmail} onChange={(e) => setClientEmail(e.target.value)} className="w-full border-0 border-b border-line bg-transparent py-3 text-[16px] focus:outline-none focus:border-gold" />
            </div>
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-stone mb-3">Service Title</label>
              <input required placeholder="e.g. Brand Identity" value={serviceTitle} onChange={(e) => setServiceTitle(e.target.value)} className="w-full border-0 border-b border-line bg-transparent py-3 text-[16px] focus:outline-none focus:border-gold" />
            </div>
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-stone mb-3">Total (₦)</label>
              <input required type="number" min="1" value={totalNaira} onChange={(e) => setTotalNaira(e.target.value)} className="w-full border-0 border-b border-line bg-transparent py-3 text-[16px] focus:outline-none focus:border-gold" />
            </div>
            <div className="md:col-span-2">
              <button
                type="submit"
                disabled={creating}
                className="inline-flex items-center gap-2.5 font-sans text-[13px] font-semibold uppercase tracking-wider px-8 py-4 rounded-sm bg-charcoal text-ivory transition-all duration-500 ease-studio hover:bg-gold hover:text-charcoal disabled:opacity-50"
              >
                {creating ? "Creating…" : "Create Quote & Email Client"}
              </button>
              {createError && <p className="mt-4 text-xs text-red-700">{createError}</p>}
              {lastCheckoutUrl && (
                <p className="mt-4 text-xs text-olive break-all">
                  Sent. Checkout link: {lastCheckoutUrl}
                </p>
              )}
            </div>
          </form>
        </Reveal>

        <Reveal>
          <h2 className="font-display text-2xl mb-6 mt-16">All Quotes</h2>
          {!quotes || quotes.length === 0 ? (
            <p className="text-stone text-sm">No quotes yet.</p>
          ) : (
            <div className="border border-line">
              {quotes.map((q) => (
                <div key={q.id} className="flex justify-between items-center flex-wrap gap-4 px-6 py-6 border-b border-line last:border-b-0">
                  <div>
                    <h3 className="font-display text-lg">{q.service_title}</h3>
                    <p className="font-mono text-[11px] text-stone uppercase tracking-wider mt-1">
                      {q.client_name || "—"} · {q.client_email}
                    </p>
                  </div>
                  <div className="flex items-center gap-6">
                    <span className="font-mono text-[11px] uppercase tracking-wider">
                      Deposit {q.deposit_paid ? "✓" : "—"} · Balance {q.balance_paid ? "✓" : "—"}
                    </span>
                    <span className="font-display text-lg">₦{q.total_naira.toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Reveal>
      </div>
      <Footer />
    </>
  );
}
