import Link from "next/link";

export default function MenuRow({
  num,
  title,
  description,
  priceLabel,
  actionHref,
  actionLabel,
}: {
  num: string;
  title: string;
  description: string;
  priceLabel: string;
  actionHref: string;
  actionLabel: string;
}) {
  return (
    <div className="grid grid-cols-[60px_1fr_auto] gap-7 items-baseline px-5 py-9 border-b border-line transition-all duration-400 ease-studio hover:bg-beige hover:pl-8">
      <span className="font-mono text-xs text-gold tracking-wider">{num}</span>
      <div>
        <h3 className="font-display text-2xl md:text-3xl mb-2 tracking-tight">
          {title}
        </h3>
        <p className="text-sm text-stone max-w-[480px] leading-relaxed">
          {description}
        </p>
      </div>
      <div className="text-right whitespace-nowrap">
        <span className="block font-display text-lg mb-2.5">{priceLabel}</span>
        <Link
          href={actionHref}
          className="font-mono text-[11px] uppercase tracking-wider border-b border-charcoal pb-0.5 transition-colors duration-300 hover:text-gold hover:border-gold"
        >
          {actionLabel}
        </Link>
      </div>
    </div>
  );
}
