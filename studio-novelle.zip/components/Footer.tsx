import Link from "next/link";
import Seal from "./Seal";

export default function Footer({ quote }: { quote?: string }) {
  return (
    <footer className="max-w-[1180px] mx-auto px-8 pt-16 pb-12 border-t border-line">
      <div className="flex justify-between items-end flex-wrap gap-6">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <Seal />
            <span className="font-display text-[15px] tracking-wide">
              STUDIO NOVELLE
            </span>
          </div>
          {quote && (
            <div className="quote-trigger cursor-pointer inline-block" tabIndex={0}>
              <span className="font-mono text-[11px] uppercase tracking-wider text-stone">
                Hover for a note from the studio ↴
              </span>
              <div className="quote-hidden font-display italic text-[17px] text-olive">
                &ldquo;{quote}&rdquo;
              </div>
            </div>
          )}
        </div>
        <div className="font-mono text-[11px] text-stone tracking-wider text-right leading-relaxed">
          WHERE PREMIUM BRANDS BEGIN.
          <br />© STUDIO NOVELLE
          <br />
          <Link href="/materials" className="hover:text-charcoal transition-colors">
            Material Library
          </Link>
          {" · "}
          <Link href="/vault" className="hover:text-charcoal transition-colors">
            Client Login
          </Link>
        </div>
      </div>
    </footer>
  );
}
