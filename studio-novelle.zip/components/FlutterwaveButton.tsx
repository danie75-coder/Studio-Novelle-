"use client";

import Script from "next/script";
import { useState } from "react";

declare global {
  interface Window {
    FlutterwaveCheckout?: (opts: Record<string, unknown>) => void;
  }
}

export default function FlutterwaveButton({
  email,
  name,
  amountNaira,
  description,
  metadata,
  onSuccess,
}: {
  email: string;
  name: string;
  amountNaira: number;
  description: string;
  metadata: Record<string, unknown>;
  onSuccess: (transactionId: string) => void;
}) {
  const [scriptReady, setScriptReady] = useState(false);
  const [loading, setLoading] = useState(false);

  const publicKey = process.env.NEXT_PUBLIC_FLUTTERWAVE_PUBLIC_KEY;

  function handlePay() {
    if (!publicKey) {
      alert("Payments are not configured yet. Please contact the studio directly.");
      return;
    }
    if (!window.FlutterwaveCheckout) {
      alert("Payment is still loading — try again in a moment.");
      return;
    }

    setLoading(true);
    const txRef = `sn-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    window.FlutterwaveCheckout({
      public_key: publicKey,
      tx_ref: txRef,
      amount: amountNaira,
      currency: "NGN",
      payment_options: "card, banktransfer, ussd",
      customer: { email, name },
      customizations: {
        title: "Studio Novelle",
        description,
      },
      // Whatever the caller passes ends up on the transaction record
      // Flutterwave sends back — both to this callback and to the
      // webhook — so this must carry everything downstream code needs
      // to know what was paid for (service vs. quote deposit/balance).
      meta: { ...metadata, name },
      callback: (response: { status: string; transaction_id: string }) => {
        setLoading(false);
        if (response.status === "successful" || response.status === "completed") {
          onSuccess(String(response.transaction_id));
        }
      },
      onclose: () => setLoading(false),
    });
  }

  return (
    <>
      <Script
        src="https://checkout.flutterwave.com/v3.js"
        strategy="lazyOnload"
        onLoad={() => setScriptReady(true)}
      />
      <button
        type="button"
        disabled={!email || loading}
        onClick={handlePay}
        className="inline-flex items-center gap-2.5 font-sans text-[13px] font-semibold uppercase tracking-wider px-8 py-4 rounded-sm border border-charcoal text-charcoal transition-all duration-500 ease-studio hover:border-gold hover:text-gold disabled:opacity-50 disabled:pointer-events-none"
      >
        {loading ? "Opening Flutterwave…" : !scriptReady ? "Loading…" : "Pay with Flutterwave"}
      </button>
    </>
  );
}
