import Link from "next/link";
import Nav from "./Nav";
import Footer from "./Footer";
import Reveal from "./Reveal";
import CaseFileHeader from "./CaseFileHeader";
import type { Project } from "@/lib/projects";
import { getNextProject } from "@/lib/projects";

function Stars({ n }: { n: number }) {
  return (
    <span className="text-gold tracking-[3px] text-sm">
      {"★".repeat(n)}
      <span className="text-line">{"★".repeat(5 - n)}</span>
    </span>
  );
}

export default function CaseStudy({ project }: { project: Project }) {
  const next = getNextProject(project.slug);

  return (
    <>
      <Nav backLink={{ href: "/work", label: "← Selected Work" }} />

      <CaseFileHeader
        fileNo={project.fileNo}
        title={project.name}
        client={project.client}
        industry={project.industry}
        objective={project.objective}
        status={project.status}
      />

      <Reveal>
        <div
          className="max-w-[1180px] mx-auto px-8 my-24 h-[60vh] min-h-[380px] relative"
          style={{ background: project.gradient }}
        >
          <span className="absolute bottom-6 left-6 font-mono text-[10px] uppercase tracking-wider bg-ivory/70 px-2.5 py-1.5">
            {project.plateLabel}
          </span>
        </div>
      </Reveal>

      <section className="max-w-[1180px] mx-auto px-8">
        <Reveal>
          <div className="grid md:grid-cols-[200px_1fr] gap-14 py-16">
            <span className="font-mono text-xs uppercase tracking-widest text-gold">
              The Challenge
            </span>
            <div>
              <h2 className="font-display text-[26px] md:text-4xl leading-snug tracking-tight max-w-[640px] mb-5">
                {project.challenge.title}
              </h2>
              <p className="text-stone text-base leading-relaxed max-w-[600px]">
                {project.challenge.body}
              </p>
            </div>
          </div>
        </Reveal>

        <Reveal>
          <div className="grid md:grid-cols-[200px_1fr] gap-14 py-16 border-t border-line">
            <span className="font-mono text-xs uppercase tracking-widest text-gold">
              The Approach
            </span>
            <div>
              <h2 className="font-display text-[26px] md:text-4xl leading-snug tracking-tight max-w-[640px] mb-5">
                {project.approach.title}
              </h2>
              <p className="text-base leading-relaxed max-w-[600px] mb-7">
                {project.approach.body}
              </p>
              <div className="flex flex-wrap gap-3">
                {project.approach.materials.map((m) => (
                  <span
                    key={m}
                    className="font-mono text-[11px] uppercase tracking-wider border border-line px-4 py-2.5 transition-colors duration-300 hover:border-gold hover:text-gold"
                  >
                    {m}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </Reveal>

        <Reveal>
          <div className="grid md:grid-cols-[200px_1fr] gap-14 py-16 border-t border-line">
            <span className="font-mono text-xs uppercase tracking-widest text-gold">
              The Work
            </span>
            <div>
              <h2 className="font-display text-[26px] md:text-4xl leading-snug tracking-tight max-w-[640px] mb-5">
                {project.work.title}
              </h2>
              <p className="text-stone text-base leading-relaxed max-w-[600px] mb-7">
                {project.work.body}
              </p>
              <div className="grid md:grid-cols-[1.3fr_1fr] gap-px bg-line">
                <div className="h-64" style={{ background: project.gradient }} />
                <div className="h-64" style={{ background: "linear-gradient(135deg, #E9DFCC, #83786A 150%)" }} />
              </div>
            </div>
          </div>
        </Reveal>
      </section>

      <Reveal>
        <section className="py-28 bg-charcoal text-ivory text-center">
          <div className="max-w-[1180px] mx-auto px-8">
            <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-8">
              The Decision That Changed Everything
            </span>
            <p className="font-display italic text-2xl md:text-[38px] max-w-[760px] mx-auto leading-snug">
              &ldquo;{project.decision}&rdquo;
            </p>
          </div>
        </section>
      </Reveal>

      <Reveal>
        <section className="max-w-[1180px] mx-auto px-8 py-28 grid md:grid-cols-[200px_1fr] gap-14">
          <span className="font-mono text-xs uppercase tracking-widest text-gold">
            Design DNA
          </span>
          <div className="max-w-[520px]">
            {project.dna.map(([label, n]) => (
              <div key={label} className="flex justify-between items-center py-4.5 border-b border-line">
                <span className="font-display text-base">{label}</span>
                <Stars n={n} />
              </div>
            ))}
          </div>
        </section>
      </Reveal>

      <Reveal>
        <section className="max-w-[1180px] mx-auto px-8 py-24 border-t border-line">
          <Link href={`/work/${next.slug}`} className="flex justify-between items-center gap-6 flex-wrap group">
            <div>
              <span className="font-mono text-xs uppercase tracking-widest text-gold block mb-3.5">
                Next Case File — {next.fileNo}
              </span>
              <h3 className="font-display font-light text-[32px] md:text-[56px] tracking-tight transition-colors duration-300 group-hover:text-gold">
                {next.name} →
              </h3>
            </div>
            <span className="font-display text-4xl text-stone transition-all duration-400 ease-studio group-hover:translate-x-2.5 group-hover:text-gold">
              ↗
            </span>
          </Link>
        </section>
      </Reveal>

      <Footer />
    </>
  );
}
