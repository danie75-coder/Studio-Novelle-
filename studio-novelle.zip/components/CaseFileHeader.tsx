export default function CaseFileHeader({
  fileNo,
  title,
  client,
  industry,
  objective,
  status,
}: {
  fileNo: string;
  title: string;
  client: string;
  industry: string;
  objective: string;
  status: string;
}) {
  return (
    <header className="max-w-[1180px] mx-auto px-8 pt-20">
      <div className="flex justify-between items-start mb-10">
        <span className="font-mono text-xs uppercase tracking-widest text-gold">
          Case File — {fileNo}
        </span>
        <div className="w-20 h-20 rounded-full border-[1.5px] border-olive flex items-center justify-center -rotate-[10deg] opacity-80 shrink-0">
          <span className="font-mono text-[9px] text-center leading-tight text-olive uppercase tracking-wide">
            Studio
            <br />
            Novelle
            <br />
            Certified
          </span>
        </div>
      </div>
      <h1 className="font-display font-light text-[48px] md:text-[96px] leading-[0.94] tracking-tight mb-11">
        {title}
      </h1>
      <dl className="grid grid-cols-2 md:grid-cols-4 gap-6 py-8 border-t border-b border-charcoal">
        <div>
          <dt className="font-mono text-[10px] uppercase tracking-wider text-stone mb-2.5">
            Client
          </dt>
          <dd className="font-display text-lg">{client}</dd>
        </div>
        <div>
          <dt className="font-mono text-[10px] uppercase tracking-wider text-stone mb-2.5">
            Industry
          </dt>
          <dd className="font-display text-lg">{industry}</dd>
        </div>
        <div>
          <dt className="font-mono text-[10px] uppercase tracking-wider text-stone mb-2.5">
            Objective
          </dt>
          <dd className="font-display text-[15px] leading-tight">{objective}</dd>
        </div>
        <div>
          <dt className="font-mono text-[10px] uppercase tracking-wider text-stone mb-2.5">
            Status
          </dt>
          <dd>
            <span className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-wider px-3 py-1.5 rounded-full bg-olive/10 text-olive">
              <span className="w-1.5 h-1.5 rounded-full bg-olive" />
              {status}
            </span>
          </dd>
        </div>
      </dl>
    </header>
  );
}
