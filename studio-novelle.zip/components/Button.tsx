import Link from "next/link";
import { ReactNode } from "react";

type Variant = "primary" | "outline" | "ghost";

export default function Button({
  href,
  children,
  variant = "primary",
  dark = false,
}: {
  href: string;
  children: ReactNode;
  variant?: Variant;
  dark?: boolean;
}) {
  const base =
    "inline-flex items-center gap-2.5 font-sans text-[13px] font-semibold uppercase tracking-wider px-8 py-4 rounded-sm transition-all duration-500 ease-studio";

  const styles: Record<Variant, string> = {
    primary: dark
      ? "bg-ivory text-charcoal hover:bg-gold hover:-translate-y-0.5"
      : "bg-charcoal text-ivory hover:bg-gold hover:text-charcoal hover:-translate-y-0.5",
    outline:
      "bg-transparent text-charcoal border border-charcoal hover:border-gold hover:text-gold",
    ghost:
      "bg-transparent text-charcoal px-1 py-4 border-b border-transparent hover:border-gold hover:text-gold",
  };

  return (
    <Link href={href} className={`${base} ${styles[variant]}`}>
      {children}
    </Link>
  );
}
