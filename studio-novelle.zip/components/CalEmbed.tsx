"use client";

import Script from "next/script";

// Replace with your real Cal.com username/event slug once the account
// is set up, e.g. "studio-novelle/discovery-call".
const CAL_LINK = process.env.NEXT_PUBLIC_CAL_LINK || "studio-novelle/discovery-call";

export default function CalEmbed() {
  return (
    <>
      <div
        id="studio-novelle-cal"
        style={{ width: "100%", height: "100%", minHeight: "700px", overflow: "scroll" }}
      />
      <Script id="cal-embed-init" strategy="lazyOnload">
        {`
          (function (C, A, L) {
            let p = function (a, ar) { a.q.push(ar); };
            let d = C.document;
            C.Cal = C.Cal || function () {
              let cal = C.Cal;
              let ar = arguments;
              if (!cal.loaded) {
                cal.ns = {};
                cal.q = cal.q || [];
                d.head.appendChild(d.createElement("script")).src = A;
                cal.loaded = true;
              }
              if (ar[0] === L) {
                const api = function () { p(api, arguments); };
                const namespace = ar[1];
                api.q = api.q || [];
                if (typeof namespace === "string") {
                  cal.ns[namespace] = cal.ns[namespace] || api;
                  p(cal.ns[namespace], ar);
                  p(cal, ["initNamespace", namespace]);
                } else p(cal, ar);
                return;
              }
              p(cal, ar);
            };
          })(window, "https://app.cal.com/embed/embed.js", "init");

          Cal("init", { origin: "https://cal.com" });

          Cal("inline", {
            elementOrSelector: "#studio-novelle-cal",
            calLink: "${CAL_LINK}",
            layout: "month_view",
          });

          Cal("ui", {
            theme: "light",
            styles: { branding: { brandColor: "#B08D53" } },
            hideEventTypeDetails: false,
          });
        `}
      </Script>
    </>
  );
}
