import Link from "next/link";

export default function ProjectCard({
  href,
  fileNo,
  name,
  industry,
  gradient,
}: {
  href: string;
  fileNo: string;
  name: string;
  industry: string;
  gradient: string;
}) {
  return (
    <Link
      href={href}
      className="block bg-ivory p-8 transition-colors duration-400 hover:bg-beige"
    >
      <div className="h-52 mb-6" style={{ background: gradient }} />
      <div className="font-mono text-[10px] uppercase tracking-wider text-gold mb-3.5">
        {fileNo}
      </div>
      <h4 className="font-display text-2xl mb-2">{name}</h4>
      <div className="font-mono text-[10px] uppercase tracking-wider text-stone">
        {industry}
      </div>
    </Link>
  );
}
