import Link from "next/link";
import Seal from "./Seal";

const links = [
  { href: "/work", label: "Selected Work" },
  { href: "/what-if", label: "What If?" },
  { href: "/about", label: "Philosophy" },
  { href: "/services", label: "Services" },
  { href: "/notebook", label: "Notebook" },
];

export default function Nav({
  active,
  backLink,
}: {
  active?: string;
  backLink?: { href: string; label: string };
}) {
  return (
    <nav className="sticky top-0 z-50 bg-ivory/90 backdrop-blur-md border-b border-line">
      <div className="max-w-[1180px] mx-auto flex items-center justify-between px-8 py-5">
        <Link href="/" className="lockup flex items-center gap-3">
          <Seal />
          <span className="font-display text-[15px] tracking-wide">
            STUDIO NOVELLE
          </span>
        </Link>

        {backLink ? (
          <Link
            href={backLink.href}
            className="font-mono text-[11px] uppercase tracking-wider text-stone hover:text-charcoal transition-colors"
          >
            {backLink.label}
          </Link>
        ) : (
          <>
            <div className="hidden lg:flex gap-7 text-[12px] uppercase tracking-wider text-stone">
              {links.map((l) => (
                <Link
                  key={l.href}
                  href={l.href}
                  className={`transition-colors hover:text-charcoal ${
                    active === l.href ? "text-charcoal" : ""
                  }`}
                >
                  {l.label}
                </Link>
              ))}
            </div>
            <Link
              href="/book"
              className="font-sans text-[12px] font-semibold uppercase tracking-wider px-5 py-2.5 border border-charcoal rounded-sm transition-all duration-400 ease-studio hover:bg-charcoal hover:text-ivory"
            >
              Book a Project
            </Link>
          </>
        )}
      </div>
    </nav>
  );
}
