export default function Seal({ size = 36 }: { size?: number }) {
  return (
    <div
      className="seal"
      style={{ width: size, height: size, fontSize: size * 0.39 }}
    >
      N
    </div>
  );
}
