"use client";

import Script from "next/script";
import { useState } from "react";

declare global {
  interface Window {
    PaystackPop?: {
      setup: (opts: Record<string, unknown>) => { openIframe: () => void };
    };
  }
}

export default function PaystackButton({
  email,
  amountNaira,
  metadata,
  onSuccess,
}: {
  email: string;
  amountNaira: number;
  metadata: Record<string, unknown>;
  onSuccess: (reference: string) => void;
}) {
  const [scriptReady, setScriptReady] = useState(false);
  const [loading, setLoading] = useState(false);

  const publicKey = process.env.NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY;

  function handlePay() {
    if (!publicKey) {
      alert("Payments are not configured yet. Please contact the studio directly.");
      return;
    }
    if (!window.PaystackPop) {
      alert("Payment is still loading — try again in a moment.");
      return;
    }

    setLoading(true);
    const handler = window.PaystackPop.setup({
      key: publicKey,
      email,
      amount: Math.round(amountNaira * 100), // kobo
      currency: "NGN",
      metadata,
      callback: (response: { reference: string }) => {
        setLoading(false);
        onSuccess(response.reference);
      },
      onClose: () => setLoading(false),
    });
    handler.openIframe();
  }

  return (
    <>
      <Script
        src="https://js.paystack.co/v1/inline.js"
        strategy="lazyOnload"
        onLoad={() => setScriptReady(true)}
      />
      <button
        type="button"
        disabled={!email || loading}
        onClick={handlePay}
        className="inline-flex items-center gap-2.5 font-sans text-[13px] font-semibold uppercase tracking-wider px-8 py-4 rounded-sm bg-charcoal text-ivory transition-all duration-500 ease-studio hover:bg-gold hover:text-charcoal hover:-translate-y-0.5 disabled:opacity-50 disabled:pointer-events-none"
      >
        {loading ? "Opening Paystack…" : !scriptReady ? "Loading…" : "Pay Now"}
      </button>
    </>
  );
}
